import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { 
    Plus, Search, Filter, ArrowUpRight, ArrowDownRight, 
    Calendar, Tag, FileText, X, Check, Save, TrendingDown,
    DollarSign, Briefcase, CreditCard, Layers
} from 'lucide-react';

const Expenses = () => {
    const { 
        expenses, addExpense, deleteExpense, 
        businessProfile, hasPermission, isViewOnly 
    } = useAppContext();
    
    const [searchTerm, setSearchTerm] = useState('');
    const [isAdding, setIsAdding] = useState(false);
    const [formData, setFormData] = useState({
        title: '',
        amount: '',
        category: 'General',
        date: new Date().toISOString().split('T')[0],
        notes: ''
    });

    const categories = ['General', 'Inventory', 'Logistics', 'Payroll', 'Utilities', 'Marketing', 'Rent', 'Other'];

    const filteredExpenses = useMemo(() => {
        return expenses
            .filter(e => 
                e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                e.category.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .sort((a, b) => new Date(b.date) - new Date(a.date));
    }, [expenses, searchTerm]);

    const totalExpenses = useMemo(() => {
        return filteredExpenses.reduce((sum, e) => sum + (parseFloat(e.amount) || 0), 0);
    }, [filteredExpenses]);

    const handleSubmit = (e) => {
        e.preventDefault();
        addExpense({
            ...formData,
            amount: parseFloat(formData.amount) || 0
        });
        setIsAdding(false);
        setFormData({
            title: '',
            amount: '',
            category: 'General',
            date: new Date().toISOString().split('T')[0],
            notes: ''
        });
    };

    return (
        <div className="animate-fade-in flex flex-col gap-8 pb-12">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 pb-8 border-b border-black/5">
                <div>
                    <h1 className="text-6xl font-black tracking-tighter text-ink-primary leading-none mb-4">Outflow.</h1>
                    <p className="text-sm font-medium text-ink-secondary tracking-tight uppercase opacity-50">Expense Management & Fiscal Tracking</p>
                </div>
                <div className="flex items-center gap-6">
                    <div className="text-right mr-4">
                        <div className="text-sm font-black uppercase tracking-[0.2em] text-ink-secondary opacity-40 mb-1">Total Periodic Outflow</div>
                        <div className="text-4xl font-black text-ink-primary tracking-tighter">
                            {businessProfile?.currencySymbol || '$'}{totalExpenses.toLocaleString()}
                        </div>
                    </div>
                    {hasPermission('ADD_EXPENSE') && (
                        <button className="btn-signature h-16" onClick={() => setIsAdding(true)}>
                            LOG OUTFLOW
                            <div className="icon-nest">
                                <Plus size={20} />
                            </div>
                        </button>
                    )}
                </div>
            </div>

            {/* Quick Stats & Controls */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="glass-panel p-6 bg-surface border border-black/5 flex items-center gap-6 rounded-bento">
                    <div className="w-16 h-16 rounded-2xl bg-red-50 text-red-500 flex items-center justify-center shrink-0">
                        <TrendingDown size={28} />
                    </div>
                    <div>
                        <div className="text-sm font-black uppercase tracking-widest text-ink-secondary opacity-40 mb-1">Active Drain</div>
                        <div className="text-3xl font-black text-ink-primary tracking-tighter">{filteredExpenses.length} Records</div>
                    </div>
                </div>

                <div className="md:col-span-2 relative group">
                    <Search size={24} className="absolute left-8 top-1/2 -translate-y-1/2 text-ink-primary opacity-20 group-focus-within:opacity-100 transition-opacity" />
                    <input 
                        type="text" 
                        placeholder="Search expenditure records..." 
                        className="input-field !pl-20 !py-8 !rounded-pill bg-surface border border-black/5 shadow-premium text-xl font-bold placeholder:text-ink-secondary/30"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            {/* Expenses Table/Ledger */}
            <div className="glass-panel !p-0 !rounded-bento overflow-hidden border border-black/5 shadow-premium">
                <div className="bg-ink-primary p-6 flex items-center gap-4">
                    <Briefcase size={20} className="text-accent-signature" />
                    <h2 className="text-xs font-black uppercase tracking-[0.3em] text-surface">Consolidated Ledger</h2>
                </div>
                
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b border-black/5 bg-canvas">
                                <th className="p-6 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50">Transaction Identifier</th>
                                <th className="p-6 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50">Classification</th>
                                <th className="p-6 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50">Temporal Log</th>
                                <th className="p-6 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50 text-right">Capital Value</th>
                                <th className="p-6 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-black/5 bg-white">
                            {filteredExpenses.map(expense => (
                                <tr key={expense.id} className="group hover:bg-canvas transition-colors">
                                    <td className="p-10">
                                        <div className="flex items-center gap-5">
                                            <div className="w-12 h-12 rounded-2xl bg-surface border border-black/5 shadow-sm flex items-center justify-center text-ink-primary group-hover:bg-accent-signature group-hover:border-transparent transition-all">
                                                <Tag size={18} />
                                            </div>
                                            <div>
                                                <div className="text-base font-black text-ink-primary uppercase tracking-tight">{expense.title}</div>
                                                <div className="text-sm font-bold text-ink-secondary uppercase tracking-widest opacity-40">{expense.notes || 'No meta-data provided'}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="p-10">
                                        <span className="px-5 py-2 rounded-pill bg-canvas text-ink-primary text-xs font-black uppercase tracking-widest border border-black/5">
                                            {expense.category}
                                        </span>
                                    </td>
                                    <td className="p-10">
                                        <div className="flex items-center gap-3 text-sm font-bold text-ink-secondary uppercase tracking-tight">
                                            <Calendar size={14} className="opacity-30" />
                                            {new Date(expense.date).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}
                                        </div>
                                    </td>
                                    <td className="p-6 text-right">
                                        <div className="text-2xl font-black text-ink-primary tracking-tighter">
                                            {businessProfile?.currencySymbol || '$'}{parseFloat(expense.amount).toLocaleString()}
                                        </div>
                                    </td>
                                    <td className="p-6 text-right">
                                        {hasPermission('DELETE_EXPENSE') && (
                                            <button 
                                                className="w-10 h-10 rounded-2xl bg-red-50 text-red-500 flex items-center justify-center opacity-0 group-hover:opacity-100 hover:scale-110 transition-all ml-auto"
                                                onClick={() => {
                                                    if(window.confirm('Authorize record deletion?')) deleteExpense(expense.id);
                                                }}
                                            >
                                                <X size={16} />
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {filteredExpenses.length === 0 && (
                    <div className="p-32 text-center">
                        <div className="flex justify-center mb-6 opacity-10">
                            <Layers size={64} strokeWidth={1} />
                        </div>
                        <p className="text-sm font-black uppercase tracking-[0.4em] text-[#666]">Vault Integrity Confirmed: Zero Records</p>
                    </div>
                )}
            </div>

            {/* Log Outflow Modal */}
            {isAdding && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[600px] !overflow-hidden">
                        <button 
                            onClick={() => setIsAdding(false)}
                            className="absolute top-8 right-8 w-12 h-12 rounded-pill bg-canvas flex items-center justify-center text-ink-primary hover:scale-110 transition-transform z-10"
                        >
                            <X size={20} />
                        </button>

                        <div className="absolute top-0 left-0 w-2 h-full bg-accent-signature"></div>

                        <div className="mb-12">
                            <h3 className="text-4xl font-black tracking-tighter text-ink-primary uppercase mb-2">Log Expense</h3>
                            <p className="text-xs font-bold text-ink-secondary uppercase tracking-widest opacity-40">Financial Inventory Update</p>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="md:col-span-2">
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Transaction Title</label>
                                    <input 
                                        required 
                                        type="text" 
                                        placeholder="Identify the expenditure..."
                                        className="input-field !rounded-2xl !py-5 font-black text-xl" 
                                        value={formData.title} 
                                        onChange={e => setFormData({...formData, title: e.target.value})} 
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Capital Value</label>
                                    <div className="relative">
                                        <div className="absolute left-6 top-1/2 -translate-y-1/2 text-xl font-black text-ink-primary opacity-30">
                                            {businessProfile?.currencySymbol || '$'}
                                        </div>
                                        <input 
                                            required 
                                            type="number" 
                                            step="0.01"
                                            className="input-field !pl-12 !rounded-2xl !py-5 font-black text-2xl" 
                                            value={formData.amount} 
                                            onChange={e => setFormData({...formData, amount: e.target.value})} 
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Sector Label</label>
                                    <select 
                                        className="input-field !rounded-2xl !py-5 font-bold appearance-none bg-canvas" 
                                        value={formData.category} 
                                        onChange={e => setFormData({...formData, category: e.target.value})}
                                    >
                                        {categories.map(c => <option key={c} value={c}>{c.toUpperCase()}</option>)}
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Date Log</label>
                                    <input 
                                        type="date" 
                                        className="input-field !rounded-2xl !py-5 font-bold bg-canvas" 
                                        value={formData.date} 
                                        onChange={e => setFormData({...formData, date: e.target.value})} 
                                    />
                                </div>

                                <div className="md:col-span-2">
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Supplemental Metadata (Notes)</label>
                                    <textarea 
                                        className="input-field !rounded-[2rem] !py-8 font-medium min-h-[140px] resize-none bg-canvas" 
                                        placeholder="Add contextual details for this outflow..."
                                        value={formData.notes} 
                                        onChange={e => setFormData({...formData, notes: e.target.value})} 
                                    />
                                </div>
                            </div>

                            <div className="flex gap-4 pt-6">
                                <button type="button" className="flex-1 py-6 rounded-pill border border-black/10 font-bold text-ink-primary hover:bg-black/5 transition-all text-xs tracking-widest uppercase" onClick={() => setIsAdding(false)}>Abort</button>
                                <button type="submit" className="btn-signature flex-[2] !py-6 !rounded-pill">
                                    AUTHORIZE LOG
                                    <div className="icon-nest">
                                        <Save size={20} />
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Expenses;
