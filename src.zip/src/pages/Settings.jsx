import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { 
    Settings as SettingsIcon, Building, Shield, Bell, Save, 
    CheckCircle2, Lock, Globe, Coins, ShieldCheck, 
    Database, RotateCcw, ChevronRight, Zap
} from 'lucide-react';

const Settings = () => {
    const { businessProfile, updateBusinessProfile, currentUser, hasPermission, resetAndSeedLocal } = useAppContext();

    const [profileData, setProfileData] = useState({
        name: businessProfile.name || '',
        country: businessProfile.country || '',
        currency: businessProfile.currency || 'USD',
        currencySymbol: businessProfile.currencySymbol || '$',
        lowStockThreshold: businessProfile.lowStockThreshold || 20
    });

    const [savedStatus, setSavedStatus] = useState(false);

    const handleSaveProfile = (e) => {
        e.preventDefault();
        updateBusinessProfile(profileData);
        setSavedStatus(true);
        setTimeout(() => setSavedStatus(false), 3000);
    };

    if (!hasPermission('MANAGE_SETTINGS')) {
        return (
            <div className="animate-fade-in flex flex-col items-center justify-center min-h-[60vh] p-8">
                <div className="glass-panel max-w-[500px] w-full text-center p-12 border-none">
                    <div className="flex justify-center mb-8">
                        <div className="bg-red-50 p-8 rounded-full text-red-500">
                            <Lock size={64} strokeWidth={2.5} />
                        </div>
                    </div>
                    <h2 className="text-4xl font-black tracking-tighter text-[#111] uppercase mb-4">Access Denied</h2>
                    <p className="text-sm font-bold text-[#666] tracking-widest uppercase opacity-40 mb-10 leading-relaxed">
                        Security Clearance Insufficient. Infrastructure parameters are restricted to Global Owners.
                    </p>
                    <button className="btn-signature w-full h-16" onClick={() => window.history.back()}>
                        SYSTEM ABORT
                        <div className="icon-nest">
                            <ShieldCheck size={20} />
                        </div>
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="animate-fade-in flex flex-col gap-8 pb-12">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 pb-8 border-b border-black/5">
                <div>
                    <h1 className="text-6xl font-black tracking-tighter text-ink-primary uppercase leading-none mb-4">Settings.</h1>
                    <p className="text-sm font-medium text-ink-secondary tracking-tight uppercase opacity-50">Global Parameters & Configuration Matrix</p>
                </div>
                {savedStatus && (
                    <div className="bg-accent-signature/10 text-ink-primary px-8 py-4 rounded-pill text-[10px] font-black uppercase tracking-widest border border-accent-signature/20 flex items-center gap-3 animate-in slide-in-from-right-6 duration-500">
                        <CheckCircle2 size={18} className="text-accent-signature" /> SYNC COMPLETED
                    </div>
                )}
            </div>

            {/* Main Config Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Left Panel: Primary Identity */}
                <div className="md:col-span-2 flex flex-col gap-8">
                    <div className="glass-panel !p-0 !rounded-bento overflow-hidden border border-black/5 shadow-premium">
                        <div className="bg-ink-primary p-6 flex items-center gap-4">
                            <Building size={20} className="text-accent-signature" />
                            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-surface">Institutional Identity</h2>
                        </div>
                        
                        <div className="p-6 bg-surface">
                            <form onSubmit={handleSaveProfile} className="space-y-10">
                                <div>
                                    <label className="block text-sm font-black uppercase tracking-[0.3em] text-ink-secondary opacity-50 mb-4">Business Legal Title</label>
                                    <input
                                        required
                                        type="text"
                                        className="input-field !rounded-2xl !py-5 font-black text-2xl !bg-canvas border border-black/5"
                                        value={profileData.name}
                                        onChange={e => setProfileData({ ...profileData, name: e.target.value })}
                                        placeholder="Institutional Name..."
                                    />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div>
                                        <label className="block text-sm font-black uppercase tracking-[0.3em] text-ink-secondary opacity-50 mb-4">Fiscal Territory</label>
                                        <div className="relative">
                                            <Globe size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-ink-primary opacity-20" />
                                            <select className="input-field !pl-16 !rounded-2xl !py-4 font-black text-lg appearance-none !bg-canvas border border-black/5" value={profileData.country} onChange={e => {
                                                const country = e.target.value;
                                                let currency = profileData.currency;
                                                let currencySymbol = profileData.currencySymbol;
                                                if (country === 'India') { currency = 'INR'; currencySymbol = '₹'; }
                                                else if (country === 'United Arab Emirates') { currency = 'AED'; currencySymbol = 'AED'; }
                                                else if (country === 'United States') { currency = 'USD'; currencySymbol = '$'; }
                                                else if (country === 'United Kingdom') { currency = 'GBP'; currencySymbol = '£'; }
                                                setProfileData({ ...profileData, country, currency, currencySymbol });
                                            }}>
                                                <option value="United Arab Emirates">UNITED ARAB EMIRATES</option>
                                                <option value="United States">UNITED STATES</option>
                                                <option value="United Kingdom">UNITED KINGDOM</option>
                                                <option value="Canada">CANADA</option>
                                                <option value="Australia">AUSTRALIA</option>
                                                <option value="India">INDIA</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-black uppercase tracking-[0.3em] text-ink-secondary opacity-50 mb-4">Currency Baseline</label>
                                        <div className="relative">
                                            <Coins size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-ink-primary opacity-20" />
                                            <select className="input-field !pl-16 !rounded-2xl !py-4 font-black text-lg appearance-none !bg-canvas border border-black/5" value={profileData.currency} onChange={e => setProfileData({ ...profileData, currency: e.target.value })}>
                                                <option value="INR">INR - INDIAN RUPEE</option>
                                                <option value="AED">AED - UAE DIRHAM</option>
                                                <option value="USD">USD - US DOLLAR</option>
                                                <option value="EUR">EUR - EURO</option>
                                                <option value="GBP">GBP - BRITISH POUND</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex gap-4 pt-8 border-t border-black/5">
                                    <button type="submit" className="btn-signature w-full !rounded-2xl !py-6 !text-base">
                                        UPDATE PARAMETERS
                                        <div className="icon-nest">
                                            <Save size={24} />
                                        </div>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    {/* Threat Intelligence / Stock Alerts */}
                    <div className="glass-panel !rounded-bento p-6 border border-black/5 flex flex-col md:flex-row items-center gap-6 bg-surface shadow-premium">
                        <div className="w-24 h-24 rounded-pill bg-orange-50 text-orange-500 flex items-center justify-center shrink-0 shadow-sm">
                            <Zap size={36} />
                        </div>
                        <div className="flex-1">
                            <div className="text-sm font-black uppercase tracking-[0.4em] text-ink-secondary opacity-40 mb-3">Operational Alerts</div>
                            <h3 className="text-2xl font-black text-ink-primary uppercase tracking-tighter mb-4">Low-Stock Sensitivity</h3>
                            <div className="flex items-center gap-6">
                                <input
                                    type="number"
                                    className="input-field !max-w-[140px] !rounded-2xl !py-4 !text-center !font-black !text-2xl bg-canvas border border-black/5"
                                    value={profileData.lowStockThreshold}
                                    onChange={e => setProfileData({ ...profileData, lowStockThreshold: parseInt(e.target.value) || 0 })}
                                />
                                <span className="text-xs font-black text-ink-secondary uppercase tracking-widest opacity-40 leading-tight">Minimum Unit<br/>Retention Baseline</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right Side: Security & Maintenance */}
                <div className="flex flex-col gap-8">
                    <div className="glass-panel !rounded-bento p-12 bg-ink-primary text-surface overflow-hidden relative shadow-2xl border-none">
                        <div className="absolute top-0 right-0 p-16 opacity-5 scale-200 pointer-events-none">
                            <ShieldCheck size={140} />
                        </div>
                        <h3 className="text-xl font-black uppercase tracking-tighter mb-3">Cloud Security</h3>
                        <div className="text-[10px] font-black uppercase tracking-[0.3em] text-accent-signature mb-10">Status: Decentralized Mock</div>
                        <p className="text-sm font-medium text-surface/50 leading-relaxed mb-12 relative z-10">
                            You are currently operating within the local simulation environment. Cloud synchronization and production database locks will activate upon enterprise deployment.
                        </p>
                        <div className="w-full h-1.5 bg-surface/10 rounded-pill overflow-hidden mb-5">
                            <div className="w-[85%] h-full bg-accent-signature"></div>
                        </div>
                        <div className="flex justify-between items-center relative z-10">
                            <span className="text-[10px] font-black uppercase tracking-widest text-surface/30">Local Integrity</span>
                            <span className="text-[10px] font-black uppercase tracking-widest text-accent-signature">85% Verified</span>
                        </div>
                    </div>

                    <div className="glass-panel !rounded-bento p-12 bg-red-50/10 border border-red-500/10 flex flex-col gap-10">
                        <div>
                            <div className="flex items-center gap-4 text-red-500 mb-6">
                                <Database size={28} />
                                <h3 className="text-base font-black uppercase tracking-[0.2em] leading-none">Factory Reset</h3>
                            </div>
                            <p className="text-[11px] font-black text-red-900/60 uppercase tracking-widest leading-relaxed">
                                Irreversibly wipe local storage and re-seed the environment with fresh transactional assets.
                            </p>
                        </div>
                        {currentUser?.roles?.includes('GLOBAL_ADMIN') && (
                            <button 
                                className="w-full py-6 rounded-pill bg-red-500 text-white font-black text-xs tracking-widest uppercase hover:bg-black transition-all flex items-center justify-center gap-3 group shadow-lg"
                                onClick={resetAndSeedLocal}
                            >
                                <RotateCcw size={18} className="group-hover:rotate-180 transition-transform duration-700" />
                                EXECUTE FULL RESET
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;
