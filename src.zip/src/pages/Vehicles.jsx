import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { 
    Truck, Map, Settings as SettingsIcon, Plus, Play, Flag, 
    FileText, AlertTriangle, X, ShoppingCart, ChevronRight,
    MapPin, Navigation, Gauge, Calendar, ShieldCheck, 
    Save, Hash, History, CheckCircle2
} from 'lucide-react';

const Vehicles = () => {
    const { 
        vehicles, addVehicle, routes, dispatchRoute, reconcileRoute, 
        products, orders, businessProfile, hasPermission 
    } = useAppContext();

    const [activeTab, setActiveTab] = useState('ROUTES'); 
    const [showVehicleModal, setShowVehicleModal] = useState(false);
    const [showDispatchModal, setShowDispatchModal] = useState(false);
    const [showReconcileModal, setShowReconcileModal] = useState(null); 

    const [vehicleForm, setVehicleForm] = useState({ name: '', plate: '' });

    const [dispatchForm, setDispatchForm] = useState({
        vehicleId: vehicles[0]?.id || '',
        driverId: '',
        initialOdometer: '',
        assignedOrders: [], 
        loadedStock: {}, 
        dispatchDate: new Date().toISOString().split('T')[0]
    });

    const [reconcileForm, setReconcileForm] = useState({
        finalOdometer: '',
        actualCash: '',
        returnedStock: {} 
    });

    const activeRoutes = routes.filter(r => r.status === 'ACTIVE');
    const pastRoutes = routes.filter(r => r.status === 'COMPLETED').sort((a,b) => new Date(b.reconciledAt) - new Date(a.reconciledAt)).slice(0, 10);

    const getExpectedLeftovers = (route) => {
        const routeSales = orders.filter(o => o.routeId === route.id);
        const soldMap = {};
        routeSales.forEach(order => {
            order.items.forEach(item => {
                soldMap[item.productId] = (soldMap[item.productId] || 0) + item.quantity;
            });
        });

        const expected = {};
        route.loadedStock.forEach(item => {
            const sold = soldMap[item.productId] || 0;
            expected[item.productId] = {
                name: products.find(p => p.id === item.productId)?.name || 'Unknown',
                loaded: item.quantity,
                sold: sold,
                leftover: Math.max(0, item.quantity - sold)
            };
        });
        return expected;
    };

    const handleAddVehicle = (e) => {
        e.preventDefault();
        addVehicle(vehicleForm);
        setVehicleForm({ name: '', plate: '' });
        setShowVehicleModal(false);
    };

    const handleDispatch = (e) => {
        e.preventDefault();
        const stockArray = Object.keys(dispatchForm.loadedStock)
            .map(id => ({ productId: id, quantity: parseInt(dispatchForm.loadedStock[id]) || 0 }))
            .filter(item => item.quantity > 0);

        if (stockArray.length === 0) {
            alert("Mandatory: Load minimum 1 Asset Unit for Dispatch.");
            return;
        }

        dispatchRoute({
            vehicleId: dispatchForm.vehicleId,
            driverId: dispatchForm.driverId,
            initialOdometer: parseInt(dispatchForm.initialOdometer),
            assignedOrders: dispatchForm.assignedOrders,
            loadedStock: stockArray
        });

        setShowDispatchModal(false);
        setDispatchForm({ vehicleId: vehicles[0]?.id || '', driverId: '', initialOdometer: '', assignedOrders: [], loadedStock: {}, dispatchDate: new Date().toISOString().split('T')[0] });
    };

    const handleAssignOrder = (orderId, isChecked) => {
        setDispatchForm(prev => {
            const newAssigned = isChecked
                ? [...prev.assignedOrders, orderId]
                : prev.assignedOrders.filter(id => id !== orderId);

            const newLoadedStock = { ...prev.loadedStock };
            const order = orders.find(o => o.id === orderId);

            if (order) {
                order.items.forEach(item => {
                    const currentVal = parseInt(newLoadedStock[item.productId]) || 0;
                    if (isChecked) newLoadedStock[item.productId] = currentVal + item.quantity;
                    else newLoadedStock[item.productId] = Math.max(0, currentVal - item.quantity);
                });
            }

            return { ...prev, assignedOrders: newAssigned, loadedStock: newLoadedStock };
        });
    };

    const openReconcile = (route) => {
        const expected = getExpectedLeftovers(route);
        const initialReturned = {};
        Object.keys(expected).forEach(id => {
            initialReturned[id] = expected[id].leftover;
        });

        setReconcileForm({
            finalOdometer: '',
            actualCash: '',
            returnedStock: initialReturned
        });
        setShowReconcileModal(route);
    };

    const handleReconcile = (e) => {
        e.preventDefault();
        const returnedArray = Object.keys(reconcileForm.returnedStock)
            .map(id => ({ productId: id, quantity: parseInt(reconcileForm.returnedStock[id]) || 0 }));

        reconcileRoute(
            showReconcileModal.id,
            parseInt(reconcileForm.finalOdometer),
            returnedArray,
            parseFloat(reconcileForm.actualCash) || 0
        );

        setShowReconcileModal(null);
    };

    return (
        <div className="animate-fade-in flex flex-col gap-8 pb-12">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 pb-8 border-b border-black/5">
                <div>
                    <h1 className="text-7xl font-black tracking-tighter text-ink-primary uppercase leading-none mb-4">Traffic.</h1>
                    <p className="text-sm font-medium text-ink-secondary tracking-tight uppercase opacity-50">Fleet Optimization & Multi-Vector Fulfillment</p>
                </div>
                
                <div className="glass-panel !p-2 !rounded-pill flex gap-1 bg-surface border-black/5 shadow-premium">
                    {[
                        { id: 'ROUTES', label: 'Dispatches', icon: Navigation },
                        { id: 'FLEET', label: 'Fleet Units', icon: Truck }
                    ].map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`px-10 py-5 rounded-pill text-[10px] font-black uppercase tracking-[0.3em] transition-all flex items-center gap-4 ${
                                activeTab === tab.id 
                                ? 'bg-ink-primary text-surface shadow-2xl' 
                                : 'bg-transparent text-ink-secondary hover:bg-canvas'
                            }`}
                        >
                            <tab.icon size={16} />
                            {tab.label} {tab.id === 'ROUTES' && activeRoutes.length > 0 && `(${activeRoutes.length})`}
                        </button>
                    ))}
                </div>
            </div>

            {activeTab === 'ROUTES' && (
                <div className="space-y-12">
                    {/* Dispatch Control */}
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-5">
                            <div className="w-2 h-8 bg-accent-signature rounded-pill shadow-lg shadow-accent-signature/20"></div>
                            <h2 className="text-xs font-black uppercase tracking-[0.5em] text-ink-primary">Active Pipeline</h2>
                        </div>
                        <button className="btn-signature h-12 text-sm" onClick={() => setShowDispatchModal(true)}>
                            INITIATE DISPATCH
                            <div className="icon-nest">
                                <Play size={16} />
                            </div>
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        {activeRoutes.map(route => {
                            const vehicle = vehicles.find(v => v.id === route.vehicleId);
                            const itemsLoaded = route.loadedStock.reduce((s, i) => s + i.quantity, 0);
                            return (
                                <div key={route.id} className="glass-panel !p-0 !rounded-bento overflow-hidden border border-black/5 hover:shadow-premium transition-all bg-surface">
                                    <div className="p-6">
                                        <div className="flex justify-between items-start mb-12">
                                            <div className="flex items-center gap-6">
                                                <div className="w-16 h-16 rounded-2xl bg-ink-primary text-accent-signature flex items-center justify-center shrink-0 shadow-xl">
                                                    <Truck size={28} />
                                                </div>
                                                <div>
                                                    <h3 className="text-2xl font-black text-ink-primary uppercase tracking-tighter leading-none mb-2">{vehicle?.name || 'GENERIC UNIT'}</h3>
                                                    <div className="text-sm font-black text-ink-secondary uppercase tracking-[0.3em] opacity-40">Agent: {route.driverId}</div>
                                                </div>
                                            </div>
                                            <span className="px-5 py-2 rounded-pill bg-accent-signature/10 text-ink-primary text-xs font-black uppercase tracking-widest border border-accent-signature/20 animate-pulse">
                                                ON MISSION
                                            </span>
                                        </div>

                                        <div className="grid grid-cols-2 gap-8 mb-12">
                                            <div className="p-6 rounded-2xl bg-canvas border border-black/5">
                                                <div className="text-sm font-black text-ink-secondary uppercase tracking-[0.3em] mb-2 opacity-40">Benchmark Odometer</div>
                                                <div className="text-2xl font-black text-ink-primary tracking-tighter">{route.initialOdometer.toLocaleString()} <span className="text-xs opacity-20 ml-1">KM</span></div>
                                            </div>
                                            <div className="p-6 rounded-2xl bg-canvas border border-black/5">
                                                <div className="text-sm font-black text-ink-secondary uppercase tracking-[0.3em] mb-2 opacity-40">Asset Loadout</div>
                                                <div className="text-2xl font-black text-ink-primary tracking-tighter">{itemsLoaded.toLocaleString()} <span className="text-xs opacity-20 ml-1">UNITS</span></div>
                                            </div>
                                        </div>

                                        <button 
                                            className="w-full py-6 rounded-pill bg-ink-primary text-accent-signature font-black text-xs tracking-[0.3em] uppercase hover:shadow-2xl transition-all flex items-center justify-center gap-4 group"
                                            onClick={() => openReconcile(route)}
                                        >
                                            TERMINATE & RECONCILE
                                            <Flag size={18} className="group-hover:translate-x-2 transition-transform" />
                                        </button>
                                    </div>
                                </div>
                            );
                        })}
                        {activeRoutes.length === 0 && (
                            <div className="col-span-full py-32 text-center glass-panel !rounded-[4rem] border-dashed border-2 border-black/5">
                                <Navigation size={64} className="mx-auto mb-6 text-[#111] opacity-5" />
                                <p className="text-sm font-black text-[#666] uppercase tracking-[0.4em] opacity-40">Zero vectors active in regional zone</p>
                            </div>
                        )}
                    </div>

                    {/* Historical Archive */}
                    <div className="pt-20">
                        <div className="flex items-center gap-5 mb-8">
                            <History size={20} className="text-ink-primary opacity-20" />
                            <h2 className="text-sm font-black uppercase tracking-[0.5em] text-ink-secondary opacity-60">Fulfillment Archive</h2>
                        </div>
                        <div className="glass-panel !p-0 !rounded-bento overflow-hidden border border-black/5 shadow-premium bg-surface">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="bg-canvas border-b border-black/5 text-[10px] font-black text-ink-secondary uppercase tracking-[0.3em]">
                                        <th className="p-10">Temporal Log</th>
                                        <th className="p-10">Unit & Vector Agent</th>
                                        <th className="p-10">Distance Magnitude</th>
                                        <th className="p-10 text-right">Fulfillment Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-black/5 bg-surface">
                                    {pastRoutes.map(route => {
                                        const vehicle = vehicles.find(v => v.id === route.vehicleId);
                                        return (
                                            <tr key={route.id} className="hover:bg-canvas transition-colors">
                                                <td className="p-10 text-xs font-black text-ink-secondary uppercase tracking-tight opacity-60">
                                                    {new Date(route.reconciledAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                                                </td>
                                                <td className="p-10">
                                                    <div className="text-base font-black text-ink-primary uppercase tracking-tight leading-none mb-2">{vehicle?.name}</div>
                                                    <div className="text-[10px] font-black text-ink-secondary uppercase tracking-[0.3em] opacity-40">{route.driverId}</div>
                                                </td>
                                                <td className="p-10 text-sm font-black text-ink-primary uppercase whitespace-nowrap tracking-tighter">
                                                    {route.finalOdometer - route.initialOdometer} <span className="text-[10px] opacity-30 ml-1">NET KM</span>
                                                </td>
                                                <td className="p-10 text-right">
                                                    <span className="px-5 py-2 rounded-pill bg-canvas text-ink-primary text-[10px] font-black uppercase tracking-widest border border-black/5 shadow-sm">
                                                        ARCHIVED
                                                    </span>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'FLEET' && (
                <div className="space-y-12">
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-5">
                            <div className="w-2 h-8 bg-accent-signature rounded-pill shadow-lg shadow-accent-signature/20"></div>
                            <h2 className="text-xs font-black uppercase tracking-[0.5em] text-ink-primary">Infrastructure Inventory</h2>
                        </div>
                        {hasPermission('MANAGE_FLEET') && (
                            <button className="btn-signature h-16" onClick={() => setShowVehicleModal(true)}>
                                REGISTER UNIT
                                <div className="icon-nest">
                                    <Plus size={22} />
                                </div>
                            </button>
                        )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                        {vehicles.map(v => (
                            <div key={v.id} className="glass-panel !p-0 !rounded-bento overflow-hidden border border-black/5 hover:shadow-premium transition-all flex flex-col group bg-surface">
                                <div className="aspect-[16/10] bg-ink-primary relative overflow-hidden">
                                    {v.image ? (
                                        <img src={v.image} className="w-full h-full object-cover opacity-80 transition-transform group-hover:scale-110 duration-700" alt={v.name} />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center text-accent-signature opacity-20">
                                            <Truck size={100} strokeWidth={1} />
                                        </div>
                                    )}
                                    <div className="absolute top-8 right-8 px-5 py-2 bg-surface/10 backdrop-blur-md rounded-pill border border-surface/20 text-surface text-[10px] font-black uppercase tracking-widest">
                                        ACTIVE UNIT
                                    </div>
                                </div>
                                <div className="p-10">
                                    <h3 className="text-2xl font-black text-ink-primary uppercase tracking-tighter mb-6 leading-none">{v.name}</h3>
                                    <div className="flex justify-between items-center mt-auto border-t border-black/5 pt-8">
                                        <div>
                                            <div className="text-sm font-black uppercase tracking-[0.3em] text-ink-secondary opacity-40 mb-2">Clearance Plate</div>
                                            <div className="text-sm font-black text-ink-primary uppercase tracking-widest">{v.plate}</div>
                                        </div>
                                        <div className="w-14 h-14 rounded-2xl bg-canvas flex items-center justify-center text-ink-primary border border-black/5 shadow-sm">
                                            <ShieldCheck size={24} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* REGISTER VEHICLE MODAL */}
            {showVehicleModal && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[500px]">
                        <button onClick={() => setShowVehicleModal(false)} className="absolute top-8 right-8 w-12 h-12 rounded-full bg-[#F5F5F0] flex items-center justify-center text-[#111] hover:scale-110 transition-transform">
                            <X size={20} />
                        </button>
                        <div className="mb-10">
                            <h3 className="text-3xl font-black tracking-tighter text-[#111] uppercase mb-2">Unit Registration</h3>
                            <p className="text-xs font-bold text-[#666] uppercase tracking-widest opacity-40">Add New Logistics Asset</p>
                        </div>
                        <form onSubmit={handleAddVehicle} className="space-y-6">
                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-[#666] mb-3 text-left">Unit Nomenclature</label>
                                <input required type="text" className="input-field !rounded-2xl !py-4 font-black" placeholder="E.G. TRANSIT-V4-NORTH" value={vehicleForm.name} onChange={e => setVehicleForm({ ...vehicleForm, name: e.target.value })} />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-[#666] mb-3 text-left">Identifier (License Plate)</label>
                                <input required type="text" className="input-field !rounded-2xl !py-4 font-bold" placeholder="XYZ-8800" value={vehicleForm.plate} onChange={e => setVehicleForm({ ...vehicleForm, plate: e.target.value })} />
                            </div>
                            <button type="submit" className="btn-signature w-full mt-6">AUTHORIZE REGISTRY</button>
                        </form>
                    </div>
                </div>
            )}

            {/* DISPATCH MODAL - Overhauled for Premium Theme */}
            {showDispatchModal && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[900px] !p-16">
                        <button onClick={() => setShowDispatchModal(false)} className="absolute top-10 right-10 w-14 h-14 rounded-full bg-[#F5F5F0] flex items-center justify-center text-[#111] hover:scale-110 transition-transform z-20">
                            <X size={24} />
                        </button>

                        <div className="mb-16">
                            <div className="flex items-center gap-4 mb-4">
                                <Navigation className="text-[#C8F135]" size={32} />
                                <h3 className="text-5xl font-black tracking-tighter text-[#111] uppercase leading-none">Command Dispatch</h3>
                            </div>
                            <p className="text-xs font-bold text-[#666] uppercase tracking-[0.4em] opacity-40">Initialize Operational Log and Asset Deployment</p>
                        </div>

                        <form onSubmit={handleDispatch} className="grid grid-cols-1 md:grid-cols-2 gap-12">
                            <div className="space-y-8">
                                <div className="p-8 bg-[#F5F5F0] rounded-[2.5rem]">
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-[#666] mb-6">Vector Assignment</label>
                                    <div className="space-y-6">
                                        <div>
                                            <label className="text-[9px] font-black text-[#111] opacity-40 uppercase block mb-2 px-1">Selected Unit</label>
                                            <select className="input-field !rounded-2xl !py-4 !bg-white border-black/5 font-black uppercase appearance-none" value={dispatchForm.vehicleId} onChange={e => setDispatchForm({ ...dispatchForm, vehicleId: e.target.value })}>
                                                {vehicles.map(v => <option key={v.id} value={v.id}>{v.name} ({v.plate})</option>)}
                                            </select>
                                        </div>
                                        <div>
                                            <label className="text-[9px] font-black text-[#111] opacity-40 uppercase block mb-2 px-1">Clearance Agent</label>
                                            <input required type="text" className="input-field !rounded-2xl !py-4 !bg-white border-black/5 font-bold" placeholder="Designate Driver..." value={dispatchForm.driverId} onChange={e => setDispatchForm({ ...dispatchForm, driverId: e.target.value })} />
                                        </div>
                                    </div>
                                </div>

                                <div className="p-8 bg-[#F5F5F0] rounded-[2.5rem]">
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-[#666] mb-6">Infrastructure Telemetry</label>
                                    <div className="space-y-6">
                                        <div>
                                            <label className="text-[9px] font-black text-[#111] opacity-40 uppercase block mb-2 px-1">Odometer Baseline</label>
                                            <input required type="number" className="input-field !rounded-2xl !py-4 !bg-white border-black/5 font-black text-xl" placeholder="KM Index..." value={dispatchForm.initialOdometer} onChange={e => setDispatchForm({ ...dispatchForm, initialOdometer: e.target.value })} />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-8 flex flex-col">
                                <div className="flex-1 p-8 bg-[#111] rounded-[2.5rem] text-white flex flex-col">
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-6 flex items-center gap-3">
                                        <ShoppingCart size={14} className="text-[#C8F135]" /> Fulfillment Pipeline
                                    </label>
                                    <div className="flex-1 overflow-y-auto max-h-[350px] space-y-3 custom-scrollbar pr-4">
                                        {products.filter(p => p.stock > 0).map(p => (
                                            <div key={p.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 group hover:border-[#C8F135]/30 transition-all">
                                                <div className="min-w-0">
                                                    <div className="text-xs font-black uppercase tracking-tight truncate">{p.name}</div>
                                                    <div className="text-[9px] font-bold text-white/30 tracking-widest">{p.stock} {p.unit} IN STOCK</div>
                                                </div>
                                                <input 
                                                    type="number" 
                                                    min="0" 
                                                    max={p.stock} 
                                                    className="w-20 bg-white/10 border-none rounded-xl p-3 text-center text-xs font-black text-[#C8F135] outline-none"
                                                    placeholder="0"
                                                    value={dispatchForm.loadedStock[p.id] || ''}
                                                    onChange={(e) => setDispatchForm({
                                                        ...dispatchForm,
                                                        loadedStock: { ...dispatchForm.loadedStock, [p.id]: e.target.value }
                                                    })}
                                                />
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <button type="submit" className="btn-signature !h-[80px] w-full text-base">
                                    AUTHORIZE DISPATCH
                                    <div className="icon-nest">
                                        <CheckCircle2 size={28} />
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* RECONCILE MODAL - Overhauled */}
            {showReconcileModal && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[800px] !p-16 flex flex-col">
                        <button onClick={() => setShowReconcileModal(null)} className="absolute top-10 right-10 w-14 h-14 rounded-full bg-[#F5F5F0] flex items-center justify-center text-[#111] hover:scale-110 transition-transform">
                            <X size={24} />
                        </button>

                        <div className="mb-12 border-b border-black/5 pb-10">
                            <div className="flex items-center gap-4 mb-4">
                                <Flag className="text-[#111]" size={32} />
                                <h3 className="text-4xl font-black tracking-tighter text-[#111] uppercase leading-none">Mission Debrief</h3>
                            </div>
                            <p className="text-xs font-bold text-[#666] uppercase tracking-[0.4em] opacity-40">Operational Reconciliation & Asset Handover</p>
                        </div>

                        <div className="flex-1 overflow-y-auto pr-6 custom-scrollbar space-y-12">
                            <form onSubmit={handleReconcile} className="space-y-12 pb-10">
                                <div className="grid grid-cols-2 gap-8">
                                    <div className="p-8 bg-[#F5F5F0] rounded-[2.5rem]">
                                        <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-[#666] mb-4">Final Telemetry</label>
                                        <div className="relative">
                                            <Gauge size={20} className="absolute left-4 top-1/2 -translate-y-1/2 opacity-20" />
                                            <input required type="number" className="input-field !pl-12 !rounded-2xl !py-4 bg-white border-black/5 font-black text-2xl" placeholder="Final KM..." value={reconcileForm.finalOdometer} onChange={e => setReconcileForm({ ...reconcileForm, finalOdometer: e.target.value })} />
                                        </div>
                                    </div>
                                    <div className="p-8 bg-[#F5F5F0] rounded-[2.5rem]">
                                        <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-[#666] mb-4">Actual Capital Recovery</label>
                                        <div className="relative">
                                            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-2xl opacity-20">{businessProfile.currencySymbol}</span>
                                            <input required type="number" step="0.01" className="input-field !pl-10 !rounded-2xl !py-4 bg-white border-black/5 font-black text-2xl text-lime-600" placeholder="0.00" value={reconcileForm.actualCash} onChange={e => setReconcileForm({ ...reconcileForm, actualCash: e.target.value })} />
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <div className="flex items-center gap-4 mb-8">
                                        <Hash size={16} className="text-[#111] opacity-20" />
                                        <h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#666]">Asset Inventory Audit</h2>
                                    </div>
                                    <div className="space-y-4">
                                        {Object.keys(getExpectedLeftovers(showReconcileModal)).map(productId => {
                                            const data = getExpectedLeftovers(showReconcileModal)[productId];
                                            const actual = parseInt(reconcileForm.returnedStock[productId]) || 0;
                                            const hasDiscrepancy = actual !== data.leftover;
                                            return (
                                                <div key={productId} className={`p-6 rounded-[2rem] border transition-all flex items-center justify-between ${hasDiscrepancy ? 'bg-red-50 border-red-100' : 'bg-[#F5F5F0] border-transparent'}`}>
                                                    <div>
                                                        <div className="text-sm font-black text-[#111] uppercase tracking-tight">{data.name}</div>
                                                        <div className="text-[9px] font-bold text-[#666] uppercase tracking-widest opacity-40 mt-1">Expected Return: {data.leftover} Units</div>
                                                    </div>
                                                    <div className="flex items-center gap-6">
                                                        {hasDiscrepancy && <AlertTriangle size={18} className="text-red-500 animate-pulse" />}
                                                        <input 
                                                            type="number" 
                                                            className="w-24 bg-white border-2 border-black/5 rounded-2xl p-4 text-center font-black text-lg outline-none focus:border-[#111]"
                                                            value={reconcileForm.returnedStock[productId] || ''}
                                                            onChange={(e) => setReconcileForm({ ...reconcileForm, returnedStock: { ...reconcileForm.returnedStock, [productId]: e.target.value } })}
                                                        />
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>

                                <button type="submit" className="btn-signature !h-[80px] w-full text-base">
                                    EXECUTE RECONCILIATION
                                    <div className="icon-nest">
                                        <ShieldCheck size={28} />
                                    </div>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            )}

            <style dangerouslySetInnerHTML={{ __html: `
                .custom-scrollbar::-webkit-scrollbar { width: 4px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.05); border-radius: 10px; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.1); }
            ` }} />
        </div>
    );
};

export default Vehicles;
