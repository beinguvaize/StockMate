import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';

const AppContext = createContext();

export const useAppContext = () => useContext(AppContext);

// Force clear old localStorage schema
const clearOldData = () => {
    if (!localStorage.getItem('ledgr_version_1')) {
        localStorage.removeItem('sm_products');
        localStorage.removeItem('sm_vehicles');
        localStorage.setItem('ledgr_version_1', '1.0');
    }
};
clearOldData();

// Migrate user roles from string to array format
const migrateUserRoles = () => {
    const saved = localStorage.getItem('sm_users');
    if (saved) {
        const users = JSON.parse(saved);
        let needsMigration = false;
        const migrated = users.map(u => {
            if (typeof u.role === 'string' && !u.roles) {
                needsMigration = true;
                return { ...u, roles: [u.role] };
            }
            return u;
        });
        if (needsMigration) {
            localStorage.setItem('sm_users', JSON.stringify(migrated));
        }
    }
};
migrateUserRoles();

// Migrate products to include taxRate
const migrateProductTax = () => {
    const saved = localStorage.getItem('sm_products');
    if (saved) {
        const products = JSON.parse(saved);
        let needsMigration = false;
        const migrated = products.map(p => {
            if (p.taxRate === undefined) {
                needsMigration = true;
                return { ...p, taxRate: 0 };
            }
            return p;
        });
        if (needsMigration) {
            localStorage.setItem('sm_products', JSON.stringify(migrated));
        }
    }
};
migrateProductTax();

// Migrate orders to include totalAmount (handle legacy "total" property)
const migrateOrders = () => {
    const saved = localStorage.getItem('sm_orders');
    if (saved) {
        try {
            const orders = JSON.parse(saved);
            let needsMigration = false;
            const migrated = orders.map(o => {
                if (o.totalAmount === undefined && o.total !== undefined) {
                    needsMigration = true;
                    return { ...o, totalAmount: o.total };
                }
                return o;
            });
            if (needsMigration) {
                localStorage.setItem('sm_orders', JSON.stringify(migrated));
            }
        } catch (e) {
            console.error("Order migration failed", e);
        }
    }
};
migrateOrders();

// Enhanced Initial Mock Data
// mockdata: Expanded products for testing
const INITIAL_PRODUCTS = [
    { id: '1', sku: 'PCUP-210', name: 'Paper cup 210 ml', category: 'Cups', unit: 'pcs', costPrice: 0.50, sellingPrice: 1.00, stock: 1000, taxRate: 0, tags: ['paper'], image: '/images/paper_cups_white.png' },
    { id: '2', sku: 'PCUP-150', name: 'Paper cup 150 ml', category: 'Cups', unit: 'pcs', costPrice: 0.40, sellingPrice: 0.80, stock: 1000, taxRate: 0, tags: ['paper'], image: '/images/paper_cups_white.png' },
    { id: '3', sku: 'BPCUP-210', name: 'Paper cup bio 210 ml', category: 'Cups', unit: 'pcs', costPrice: 0.60, sellingPrice: 1.20, stock: 1000, taxRate: 0, tags: ['bio'], image: '/images/paper_cups_bio.png' },
    { id: '4', sku: 'BPCUP-150', name: 'Paper cup bio 150 ml', category: 'Cups', unit: 'pcs', costPrice: 0.50, sellingPrice: 1.00, stock: 1000, taxRate: 0, tags: ['bio'], image: '/images/paper_cups_bio.png' },
    { id: '5', sku: 'PLT-12', name: 'Plate 12 inch', category: 'Plates', unit: 'pcs', costPrice: 1.00, sellingPrice: 2.00, stock: 500, taxRate: 0, tags: [], image: '/images/paper_plates.png' },
    { id: '6', sku: 'APCV-1013', name: 'Apple cover 10*13', category: 'Covers', unit: 'pcs', costPrice: 0.10, sellingPrice: 0.25, stock: 2000, taxRate: 0, tags: ['apple'], image: '/images/plastic_covers.png' },
    { id: '7', sku: 'APCV-1316', name: 'Apple cover 13*16', category: 'Covers', unit: 'pcs', costPrice: 0.15, sellingPrice: 0.30, stock: 2000, taxRate: 0, tags: ['apple'], image: '/images/plastic_covers.png' },
    { id: '8', sku: 'APCV-1620', name: 'Apple cover 16*20', category: 'Covers', unit: 'pcs', costPrice: 0.20, sellingPrice: 0.40, stock: 2000, taxRate: 0, tags: ['apple'], image: '/images/plastic_covers.png' },
    { id: '9', sku: 'VJCV-1620', name: 'Virjin cover 16*20', category: 'Covers', unit: 'pcs', costPrice: 0.25, sellingPrice: 0.50, stock: 1000, taxRate: 0, tags: ['virjin'], image: '/images/plastic_covers.png' },
    { id: '10', sku: 'WHCV-1723', name: 'White cover 17*23', category: 'Covers', unit: 'pcs', costPrice: 0.30, sellingPrice: 0.60, stock: 1000, taxRate: 0, tags: ['white'], image: '/images/plastic_covers.png' },
    { id: '11', sku: 'PKCV-1316', name: 'Packet cover 13*16', category: 'Covers', unit: 'pcs', costPrice: 0.10, sellingPrice: 0.20, stock: 2000, taxRate: 0, tags: ['packet'], image: '/images/plastic_covers.png' },
    { id: '12', sku: 'PKCV-1620', name: 'Packet cover 16*20', category: 'Covers', unit: 'pcs', costPrice: 0.15, sellingPrice: 0.30, stock: 2000, taxRate: 0, tags: ['packet'], image: '/images/plastic_covers.png' },
    { id: '13', sku: 'LDCV-ALL', name: 'Ld cover all size', category: 'Covers', unit: 'kg', costPrice: 2.00, sellingPrice: 4.00, stock: 500, taxRate: 0, tags: ['ld'], image: '/images/plastic_covers.png' },
    { id: '14', sku: 'HMCV-ALL', name: 'Hm cover all size', category: 'Covers', unit: 'kg', costPrice: 2.50, sellingPrice: 5.00, stock: 500, taxRate: 0, tags: ['hm'], image: '/images/plastic_covers.png' },
    { id: '15', sku: 'PPCV-ALL', name: 'Pp cover all size', category: 'Covers', unit: 'kg', costPrice: 3.00, sellingPrice: 6.00, stock: 500, taxRate: 0, tags: ['pp'], image: '/images/plastic_covers.png' },
    { id: '16', sku: 'PSTR-01', name: 'Paper straw', category: 'Cutlery', unit: 'pcs', costPrice: 0.05, sellingPrice: 0.10, stock: 5000, taxRate: 0, tags: [], image: '/images/paper_straws.png' },
    { id: '17', sku: 'PKS-1818', name: 'Packing sheets 18*18', category: 'Sheets', unit: 'kg', costPrice: 1.50, sellingPrice: 3.00, stock: 300, taxRate: 0, tags: [], image: '/images/packing_sheets.png' },
    { id: '18', sku: 'PKS-1212', name: 'Packing sheet 12*12', category: 'Sheets', unit: 'kg', costPrice: 1.00, sellingPrice: 2.00, stock: 300, taxRate: 0, tags: [], image: '/images/packing_sheets.png' },
    { id: '19', sku: 'JCUP-300', name: 'Juice cup 300 ml', category: 'Cups', unit: 'pcs', costPrice: 0.80, sellingPrice: 1.50, stock: 800, taxRate: 0, tags: ['juice'], image: '/images/juice_cups.png' },
]; // mockdata ends

// mockdata: Expanded users for testing
const INITIAL_USERS = [
    { id: 'u0', name: 'Global Admin', email: 'global@ledgr.com', roles: ['GLOBAL_ADMIN'], status: 'ACTIVE' },
    { id: 'u1', name: 'Admin User', email: 'admin@ledgr.com', roles: ['OWNER'], status: 'ACTIVE' },
    { id: 'u3', name: 'Arjun Nair', email: 'arjun@ledgr.com', roles: ['STAFF'], status: 'ACTIVE' },
    { id: 'u4', name: 'Rahul V', email: 'rahul@ledgr.com', roles: ['STAFF'], status: 'ACTIVE' },
]; // mockdata ends

// mockdata: Expanded shops based in Trivandrum
const INITIAL_SHOPS = [
    { id: 's1', name: 'Lulu Hypermarket', contact: 'Store Manager', phone: '+91 471 234 5678', address: 'Lulu Mall, Akkulam, Trivandrum' },
    { id: 's2', name: 'Kunnil Hypermarket', contact: 'Kunnil Admin', phone: '+91 471 272 1500', address: 'Kulathoor, Trivandrum' },
    { id: 's3', name: 'Pothys Hypermarket', contact: 'Pothys Rep', phone: '+91 471 257 4444', address: 'Nikunjam, Trivandrum' },
    { id: 's4', name: 'Reliance SMART Bazaar', contact: 'Bazaar Mgr', phone: '+91 471 233 4455', address: 'Pazhavangadi, Trivandrum' },
    { id: 's5', name: 'More Supermarket', contact: 'More Staff', phone: '+91 471 244 5566', address: 'Sasthamangalam, Trivandrum' },
    { id: 's6', name: 'Nilgiris Supermarket', contact: 'Nilgiris Admin', phone: '+91 471 255 6677', address: 'Vazhuthacaud, Trivandrum' },
]; // mockdata ends

// mockdata: Expanded vehicles with Kerala registrations
const INITIAL_VEHICLES = [
    { id: 'v1', name: 'TATA Ace', plate: 'KL-01-BK-1234', image: '/images/van.png' },
    { id: 'v2', name: 'Mahindra Supro', plate: 'KL-01-BL-5678', image: '/images/van.png' },
    { id: 'v3', name: 'Ashok Leyland Dost', plate: 'KL-21-CA-9012', image: '/images/van.png' },
]; // mockdata ends

const INITIAL_BUSINESS = {
    name: 'Ledger Demo Corp',
    country: 'United Arab Emirates', // Default country
    currency: 'AED',
    currencySymbol: 'AED',
    lowStockThreshold: 20
};

// Available role definitions
const AVAILABLE_ROLES = [
    { key: 'GLOBAL_ADMIN', label: 'Global Admin', description: 'Superuser with unrestricted access to all segments.' },
    { key: 'OWNER', label: 'Owner', description: 'Full access to all features, including payroll and user management' },
    { key: 'STAFF', label: 'Staff', description: 'Can record sales and view inventory. Restricted from management tasks.' },
];
export { AVAILABLE_ROLES };

export const AppProvider = ({ children }) => {
    const [loading, setLoading] = useState(true);
    // Users
    const [users, setUsers] = useState(() => {
        try {
            const saved = localStorage.getItem('sm_users');
            return saved ? JSON.parse(saved) : INITIAL_USERS;
        } catch (e) {
            console.error("Failed to load users from localStorage", e);
            return INITIAL_USERS;
        }
    });

    const [currentUser, setCurrentUser] = useState(() => {
        // Force authentication bypass for UI development
        return INITIAL_USERS[0]; // Global Admin
    });

    // Business Profile
    const [businessProfile, setBusinessProfile] = useState(() => {
        try {
            const saved = localStorage.getItem('sm_business');
            return saved ? JSON.parse(saved) : INITIAL_BUSINESS;
        } catch (e) {
            console.error("Failed to load business profile", e);
            return INITIAL_BUSINESS;
        }
    });

    // Data States
    const [products, setProducts] = useState(() => {
        try {
            const saved = localStorage.getItem('sm_products');
            return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
        } catch (e) {
            return INITIAL_PRODUCTS;
        }
    });

    const [shops, setShops] = useState(() => {
        try {
            const saved = localStorage.getItem('sm_shops');
            return saved ? JSON.parse(saved) : INITIAL_SHOPS;
        } catch (e) {
            return INITIAL_SHOPS;
        }
    });

    const [orders, setOrders] = useState(() => {
        try {
            const saved = localStorage.getItem('sm_orders');
            return saved ? JSON.parse(saved) : [];
        } catch (e) {
            return [];
        }
    });

    const [expenses, setExpenses] = useState(() => {
        const saved = localStorage.getItem('sm_expenses');
        return saved ? JSON.parse(saved) : [];
    });

    const [movementLog, setMovementLog] = useState(() => {
        const saved = localStorage.getItem('sm_movement_log');
        return saved ? JSON.parse(saved) : [];
    });

    const [vehicles, setVehicles] = useState(() => {
        const saved = localStorage.getItem('sm_vehicles');
        return saved ? JSON.parse(saved) : INITIAL_VEHICLES;
    });

    const [routes, setRoutes] = useState(() => {
        const saved = localStorage.getItem('sm_routes');
        return saved ? JSON.parse(saved) : [];
    });

    // Payroll: Employees
    const [employees, setEmployees] = useState(() => {
        const saved = localStorage.getItem('sm_employees');
        return saved ? JSON.parse(saved) : [];
    });

    // Payroll: Pay Records
    const [payrollRecords, setPayrollRecords] = useState(() => {
        const saved = localStorage.getItem('sm_payroll');
        return saved ? JSON.parse(saved) : [];
    });

    const [notifications, setNotifications] = useState([]);

    const addNotification = (message, type = 'success') => {
        const id = Date.now();
        setNotifications(prev => [{ id, message, type, date: new Date().toISOString() }, ...prev].slice(0, 5));
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            setNotifications(prev => prev.filter(n => n.id !== id));
        }, 5000);
    };

    // Persistence Effects (Legacy LocalStorage Fallback + Initial Sync)
    useEffect(() => { localStorage.setItem('sm_business', JSON.stringify(businessProfile)); }, [businessProfile]);
    useEffect(() => { localStorage.setItem('sm_products', JSON.stringify(products)); }, [products]);
    useEffect(() => { localStorage.setItem('sm_shops', JSON.stringify(shops)); }, [shops]);
    useEffect(() => { localStorage.setItem('sm_orders', JSON.stringify(orders)); }, [orders]);
    useEffect(() => { localStorage.setItem('sm_expenses', JSON.stringify(expenses)); }, [expenses]);
    useEffect(() => { localStorage.setItem('sm_movement_log', JSON.stringify(movementLog)); }, [movementLog]);
    useEffect(() => { localStorage.setItem('sm_vehicles', JSON.stringify(vehicles)); }, [vehicles]);
    useEffect(() => { localStorage.setItem('sm_routes', JSON.stringify(routes)); }, [routes]);
    useEffect(() => { localStorage.setItem('sm_users', JSON.stringify(users)); }, [users]);
    useEffect(() => { localStorage.setItem('sm_employees', JSON.stringify(employees)); }, [employees]);
    useEffect(() => { localStorage.setItem('sm_payroll', JSON.stringify(payrollRecords)); }, [payrollRecords]);

    const initializingRef = useRef(false);

    // Local Auth & Init (Bypasses Supabase for now)
    useEffect(() => {
        const initializeLocalApp = async () => {
            setLoading(true);
            try {
                console.log("🚀 Initializing App in LOCAL mode...");
                
                // Try to restore session from localStorage if available
                const savedUser = localStorage.getItem('sm_current_user');
                if (savedUser) {
                    setCurrentUser(JSON.parse(savedUser));
                }
                
                // Small delay to simulate load if desired, but here we go instant
                console.log("🏁 Local Initialization Complete.");
            } catch (err) {
                console.error("Local init error:", err);
            } finally {
                setLoading(false);
            }
        };

        initializeLocalApp();
    }, []);

    // Helper: Local persistence for current user
    useEffect(() => {
        if (currentUser) {
            localStorage.setItem('sm_current_user', JSON.stringify(currentUser));
        } else {
            localStorage.removeItem('sm_current_user');
        }
    }, [currentUser]);

    // Data Actions (LOCAL ONLY)
    const login = async (email, password) => {
        // Simple local check against mock or saved users
        const user = users.find(u => u.email === email && (password === 'password' || password === 'admin123'));
        if (user) {
            setCurrentUser(user);
            return { success: true };
        }
        return { success: false, error: 'Invalid local credentials' };
    };

    const logout = async () => {
        setCurrentUser(null);
    };

    const addUser = async (userData) => {
        const newUser = {
            ...userData,
            id: `USR-${Date.now()}`,
            status: 'ACTIVE',
            roles: userData.roles || [userData.role || 'STAFF']
        };
        setUsers([...users, newUser]);
    };

    const updateUser = async (updatedUser) => {
        setUsers(users.map(u => u.id === updatedUser.id ? updatedUser : u));
    };

    const deleteUser = async (userId) => {
        if (userId === currentUser?.id) return;
        setUsers(users.filter(u => u.id !== userId));
    };

    const addShop = async (shop) => {
        const newShop = { ...shop, id: `CLI-${Date.now()}` };
        setShops([newShop, ...shops]);
    };

    const updateShop = async (updatedShop) => {
        setShops(shops.map(s => s.id === updatedShop.id ? updatedShop : s));
    };

    const deleteShop = async (shopId) => {
        setShops(shops.filter(s => s.id !== shopId));
    };

    const addExpense = async (expense) => {
        const newExpense = { 
            ...expense, 
            id: `EXP-${Date.now()}`, 
            date: new Date().toISOString(),
            route_id: expense.routeId 
        };
        setExpenses([newExpense, ...expenses]);
        addNotification(`Expense recorded: ${businessProfile?.currencySymbol || ''}${expense.amount}`, 'expense');
    };

    const logMovement = async (productId, productName, type, quantity, reason, userId) => {
        const newLog = {
            id: `LOG-${Date.now()}`,
            date: new Date().toISOString(),
            product_id: productId, 
            product_name: productName, 
            type, 
            quantity, 
            reason, 
            user_id: userId
        };
        setMovementLog(prev => [newLog, ...prev]);
    };

    const placeOrder = async (shopId, cartItems, subtotal, discount, tax, totalAmount, customerInfo, paymentMethod = 'CASH', routeId = null, status = 'COMPLETED', scheduledDate = null) => {
        let totalCogs = 0;
        const updatedProducts = [...products];

        cartItems.forEach(item => {
            const pIndex = updatedProducts.findIndex(p => p.id === item.productId);
            if (pIndex > -1) {
                if (status === 'COMPLETED' && !routeId) {
                    updatedProducts[pIndex].stock -= item.quantity;
                }
                item.cogs = updatedProducts[pIndex].costPrice * item.quantity;
                logMovement(item.productId, item.name, 'OUT', item.quantity, `Sale to Shop #${shopId}`, currentUser?.id);
            }
        });

        if (status === 'COMPLETED' && !routeId) {
            setProducts(updatedProducts);
        }

        totalCogs = cartItems.reduce((sum, item) => sum + (item.cogs || 0), 0);

        const newOrder = {
            id: `ORD-${Date.now()}`,
            shopId,
            customerInfo,
            paymentMethod,
            routeId,
            items: cartItems,
            subtotal, discount, tax, 
            totalAmount,
            totalCogs,
            date: new Date().toISOString(),
            salesRepId: currentUser?.id || 'LOCAL',
            bookedBy: currentUser?.id || 'LOCAL',
            status,
            scheduledDate: scheduledDate || new Date().toISOString().split('T')[0],
            deliveredBy: routeId || null
        };
        setOrders([newOrder, ...orders]);
        addNotification(`New Order: ${businessProfile?.currencySymbol || ''}${totalAmount.toFixed(2)}`, 'success');
        return newOrder.id;
    };

    const updateOrder = async (updatedOrder) => {
        const oldOrder = orders.find(o => o.id === updatedOrder.id);
        if (oldOrder && oldOrder.status === 'PENDING' && updatedOrder.status === 'COMPLETED') {
            const updatedProducts = [...products];
            for (const item of updatedOrder.items) {
                const pIndex = updatedProducts.findIndex(p => p.id === item.productId);
                if (pIndex > -1) {
                    updatedProducts[pIndex] = {
                        ...updatedProducts[pIndex],
                        stock: Math.max(0, updatedProducts[pIndex].stock - item.quantity)
                    };
                }
                logMovement(item.productId, item.name, 'OUT', item.quantity, `Fulfilled Order #${updatedOrder.id}`, currentUser?.id);
            }
            setProducts(updatedProducts);
        }
        setOrders(orders.map(o => o.id === updatedOrder.id ? updatedOrder : o));
    };

    const addProduct = async (product) => {
        const newProduct = { 
            ...product, 
            id: `PROD-${Date.now()}`, 
            stock: product.stock || 0, 
            taxRate: product.taxRate || 0 
        };
        setProducts([...products, newProduct]);
        if (newProduct.stock > 0) {
            logMovement(newProduct.id, newProduct.name, 'IN', newProduct.stock, 'Initial Stock', currentUser?.id);
        }
    };

    const updateProduct = async (updatedProduct) => {
        setProducts(products.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    };

    const deleteProduct = async (id) => {
        setProducts(prev => prev.filter(p => p.id !== id));
        setMovementLog(prev => prev.filter(l => l.productId !== id));
    };

    const adjustStock = async (productId, amount, reason, source = 'ADJUSTMENT') => {
        const product = products.find(p => p.id === productId);
        if (!product) return;
        const updatedProduct = { ...product, stock: Math.max(0, product.stock + amount) };
        setProducts(products.map(p => p.id === productId ? updatedProduct : p));
        const type = amount > 0 ? 'IN' : 'OUT';
        logMovement(productId, product.name, type, Math.abs(amount), reason, currentUser?.id);
    };

    /**
     * Mass Mock Data Generator
     * Generates 200+ entries for all modules to simulate production scale.
     */
    const generateMassMockData = () => {
        const categories = ['Cups', 'Plates', 'Covers', 'Cutlery', 'Sheets', 'Bags', 'Napkins'];
        const units = ['pcs', 'kg', 'box', 'set'];
        const shopNames = ['Hypermarket', 'Supermarket', 'Bazaar', 'Mart', 'Stores', 'Corner', 'Plaza'];
        const trivandrumAreas = ['Akkulam', 'Kulathoor', 'Sasthamangalam', 'Vazhuthacaud', 'Pattom', 'Lulu', 'Technopark'];

        // 1. Products (200)
        const massProducts = Array.from({ length: 200 }, (_, i) => {
            const cat = categories[i % categories.length];
            return {
                id: `PROD-MASS-${i + 1}`,
                sku: `${cat.slice(0, 3).toUpperCase()}-${100 + i}`,
                name: `${cat} Premium Type ${i + 1}`,
                category: cat,
                unit: units[i % units.length],
                costPrice: parseFloat((Math.random() * 5 + 0.1).toFixed(2)),
                sellingPrice: parseFloat((Math.random() * 10 + 6).toFixed(2)),
                stock: Math.floor(Math.random() * 5000) + 100,
                taxRate: i % 5 === 0 ? 5 : 0,
                tags: [cat.toLowerCase()],
                image: '/images/paper_cups_white.png'
            };
        });

        // 2. Shops (200)
        const massShops = Array.from({ length: 200 }, (_, i) => ({
            id: `CLI-MASS-${i + 1}`,
            name: `${trivandrumAreas[i % trivandrumAreas.length]} ${shopNames[i % shopNames.length]} #${i + 1}`,
            contact: `Manager ${i + 1}`,
            phone: `+91 471 ${1000000 + i}`,
            address: `${trivandrumAreas[i % trivandrumAreas.length]}, Trivandrum, Kerala`
        }));

        // 3. Orders (250)
        const massOrders = Array.from({ length: 250 }, (_, i) => {
            const shop = massShops[Math.floor(Math.random() * massShops.length)];
            const orderItems = Array.from({ length: Math.floor(Math.random() * 5) + 1 }, () => {
                const prod = massProducts[Math.floor(Math.random() * massProducts.length)];
                const qty = Math.floor(Math.random() * 10) + 1;
                return {
                    productId: prod.id,
                    name: prod.name,
                    quantity: qty,
                    price: prod.sellingPrice,
                    total: qty * prod.sellingPrice,
                    cogs: prod.costPrice * qty
                };
            });

            const subtotal = orderItems.reduce((s, item) => s + item.total, 0);
            return {
                id: `ORD-MASS-${i + 1}`,
                shopId: shop.id,
                items: orderItems,
                subtotal,
                discount: 0,
                tax: subtotal * 0.05,
                totalAmount: subtotal * 1.05,
                totalCogs: orderItems.reduce((s, item) => s + (item.cogs || 0), 0),
                date: new Date(Date.now() - Math.floor(Math.random() * 60 * 24 * 60 * 60 * 1000)).toISOString(),
                status: 'COMPLETED',
                paymentMethod: i % 3 === 0 ? 'CREDIT' : 'CASH'
            };
        });

        // 4. Expenses (200)
        const massExpenses = Array.from({ length: 200 }, (_, i) => ({
            id: `EXP-MASS-${i + 1}`,
            category: i % 4 === 0 ? 'Fuel' : (i % 4 === 1 ? 'Rent' : 'Utility'),
            amount: Math.floor(Math.random() * 500) + 50,
            note: `Monthly operational cost ${i + 1}`,
            date: new Date(Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000)).toISOString()
        }));

        // 5. Payroll (50 Staff & 150 PayRecords)
        const massEmployees = Array.from({ length: 50 }, (_, i) => ({
            id: `EMP-MASS-${i + 1}`,
            name: `Staff Member ${i + 1}`,
            role: i % 5 === 0 ? 'MANAGER' : 'SALES',
            salary: 1500 + (Math.random() * 2000),
            status: 'ACTIVE'
        }));

        const massPayroll = Array.from({ length: 150 }, (_, i) => ({
            id: `PAY-MASS-${i + 1}`,
            employeeId: massEmployees[i % massEmployees.length].id,
            amount: massEmployees[i % massEmployees.length].salary,
            month: 'March 2026',
            processed_at: new Date().toISOString()
        }));

        return {
            products: massProducts,
            shops: massShops,
            orders: massOrders,
            expenses: massExpenses,
            employees: massEmployees,
            payroll: massPayroll
        };
    };

    /**
     * resetAndSeedLocal: Generates 1200+ total data entries for local mode.
     */
    const resetAndSeedLocal = async () => {
        if (!confirm("🚨 MASS SEEDER: This will generate 1200+ local entries for stress testing. Proceed?")) return;
        
        setLoading(true);
        try {
            const data = generateMassMockData();
            
            setUsers(INITIAL_USERS);
            setProducts([...INITIAL_PRODUCTS, ...data.products]);
            setShops([...INITIAL_SHOPS, ...data.shops]);
            setVehicles(INITIAL_VEHICLES);
            setOrders(data.orders);
            setExpenses(data.expenses);
            setEmployees(data.employees);
            setPayrollRecords(data.payroll);
            setMovementLog([]); // Reset log for clean start

            alert("✅ Mass data seeder complete! 1200+ entries generated.");
        } catch (err) {
            console.error("Mass seeding failed:", err);
            alert("Mass seeding failed.");
        } finally {
            setLoading(false);
        }
    };

    // Helper: check if current user has a specific role
    const hasRole = (role) => {
        if (!currentUser) return false;
        const roles = currentUser.roles || (currentUser.role ? [currentUser.role] : ['STAFF']);
        if (roles.includes('GLOBAL_ADMIN')) return true;
        return roles.includes(role);
    };

    /**
     * RBAC Permission System
     * Owners can do everything.
     * Staff can only view and record sales/inventory.
     * Staff CANNOT delete, process payroll, manage users, or export reports.
     */
    const hasPermission = (permission) => {
        if (!currentUser) return false;
        const roles = currentUser.roles || (currentUser.role ? [currentUser.role] : ['STAFF']);
        if (roles.includes('OWNER') || roles.includes('GLOBAL_ADMIN')) return true;

        const staffAllowed = [
            'RECORD_SALE', 
            'VIEW_STOCK', 
            'VIEW_SALES', 
            'VIEW_EXPENSES', 
            'VIEW_FLEET',
            'ADD_CLIENT',
            'EDIT_CLIENT'
        ];
        if (roles.includes('STAFF')) {
            return staffAllowed.includes(permission);
        }
        return false;
    };

    const getUserName = (userId) => {
        const user = users.find(u => u.id === userId);
        return user ? user.name : 'Unknown User';
    };

    const getVehicleName = (vehicleId) => {
        const vehicle = vehicles.find(v => v.id === vehicleId);
        return vehicle ? vehicle.name : 'Unknown Vehicle';
    };

    const getShopName = (shopId) => {
        if (shopId === 'POS-WALKIN') return 'Walk-in Customer';
        const shop = shops.find(s => s.id === shopId);
        return shop ? shop.name : 'Unknown Shop';
    };

    const isViewOnly = () => {
        if (!currentUser) return true;
        if (currentUser.roles && currentUser.roles.length === 1 && currentUser.roles.includes('VIEW_ONLY')) return true;
        return false;
    };

    const addVehicle = async (vehicle) => {
        const newVehicle = { ...vehicle, id: `VH-${Date.now()}` };
        setVehicles([...vehicles, newVehicle]);
    };

    const updateVehicle = async (updated) => {
        setVehicles(vehicles.map(v => v.id === updated.id ? updated : v));
    };

    const dispatchRoute = async (routeData) => {
        const newRoute = {
            ...routeData,
            id: `RT-${Date.now()}`,
            status: 'ACTIVE',
            date: new Date().toISOString()
        };
        const updatedProducts = [...products];
        for (const item of routeData.loadedStock) {
            const pIndex = updatedProducts.findIndex(p => p.id === item.productId);
            if (pIndex > -1 && item.quantity > 0) {
                updatedProducts[pIndex].stock -= item.quantity;
                logMovement(item.productId, updatedProducts[pIndex].name, 'OUT', item.quantity, `Loaded onto Route ${newRoute.id}`, currentUser?.id);
            }
        }
        setProducts(updatedProducts);
        setRoutes([newRoute, ...routes]);
    };

    const reconcileRoute = async (routeId, finalOdometer, returnedStock, actualCash) => {
        const route = routes.find(r => r.id === routeId);
        if (!route) return;
        const updatedProducts = [...products];
        for (const item of returnedStock) {
            if (item.quantity > 0) {
                const pIndex = updatedProducts.findIndex(p => p.id === item.productId);
                if (pIndex > -1) {
                    updatedProducts[pIndex].stock += item.quantity;
                    logMovement(item.productId, updatedProducts[pIndex].name, 'IN', item.quantity, `Returned from Route ${routeId}`, currentUser?.id);
                }
            }
        }
        setProducts(updatedProducts);
        const updatedRoute = {
            ...route,
            status: 'COMPLETED',
            final_odometer: finalOdometer,
            actual_cash: actualCash,
            reconciled_at: new Date().toISOString()
        };
        setRoutes(routes.map(r => r.id === routeId ? updatedRoute : r));
    };

    // ========== PAYROLL ==========
    const addEmployee = async (emp) => {
        const newEmp = {
            ...emp,
            id: `EMP-${Date.now()}`,
            status: 'ACTIVE',
            created_at: new Date().toISOString()
        };
        setEmployees(prev => [...prev, newEmp]);
    };

    const updateEmployee = async (updated) => {
        setEmployees(employees.map(e => e.id === updated.id ? updated : e));
    };

    const deleteEmployee = async (empId) => {
        setEmployees(employees.filter(e => e.id !== empId));
    };

    const processPayroll = async (payRun) => {
        const newRecord = {
            ...payRun,
            id: `PAY-${Date.now()}`,
            processed_at: new Date().toISOString(),
            processed_by: currentUser?.id
        };
        setPayrollRecords(prev => [newRecord, ...prev]);
    };

    const deletePayrollRecord = async (recordId) => {
        setPayrollRecords(payrollRecords.filter(r => r.id !== recordId));
    };

    const migrateLocalToSupabase = async () => {
        console.log("Migration to Supabase is currently disabled in local mode.");
    };

    const updateBusinessProfile = async (profile) => {
        setBusinessProfile(profile);
    };

    const value = {
        currentUser, login, logout,
        businessProfile, updateBusinessProfile,
        products, addProduct, updateProduct, deleteProduct, adjustStock,
        shops, addShop, updateShop, deleteShop,
        orders, placeOrder, updateOrder,
        expenses, addExpense,
        movementLog,
        vehicles, addVehicle, updateVehicle,
        routes, dispatchRoute, reconcileRoute,
        users, addUser, updateUser, deleteUser,
        hasRole, hasPermission, isViewOnly,
        getUserName, getVehicleName, getShopName,
        employees, addEmployee, updateEmployee, deleteEmployee,
        payrollRecords, processPayroll, deletePayrollRecord,
        notifications, addNotification,
        loading, migrateLocalToSupabase, resetAndSeedLocal
    };

    return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
