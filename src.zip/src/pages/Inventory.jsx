import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Plus, PackagePlus, AlertCircle, History, Tag as TagIcon, Barcode as BarcodeIcon, X, CheckCircle2, Pencil, Trash2 } from 'lucide-react';
import Barcode from 'react-barcode';

const CATEGORIES = ['Electronics', 'Accessories', 'Furniture', 'Clothing', 'Other'];
const UNITS = ['pcs', 'kg', 'ltr', 'box', 'set'];

const Inventory = () => {
    const { products, addProduct, updateProduct, deleteProduct, adjustStock, movementLog, businessProfile, hasPermission } = useAppContext();

    const [showAddModal, setShowAddModal] = useState(false);
    const [editingProduct, setEditingProduct] = useState(null);
    const [showHistoryModal, setShowHistoryModal] = useState(false);
    const [adjustAmounts, setAdjustAmounts] = useState({});
    const [adjustReasons, setAdjustReasons] = useState({});
    const [adjustSources, setAdjustSources] = useState({});

    const [formData, setFormData] = useState({
        name: '', sku: '', category: CATEGORIES[0], unit: UNITS[0],
        costPrice: '', sellingPrice: '', stock: '', taxRate: '', tags: ''
    });

    const openAddModal = () => {
        setEditingProduct(null);
        setFormData({ name: '', sku: '', category: CATEGORIES[0], unit: UNITS[0], costPrice: '', sellingPrice: '', stock: '', taxRate: '', tags: '' });
        setShowAddModal(true);
    };

    const openEditModal = (p) => {
        setEditingProduct(p);
        setFormData({
            ...p,
            taxRate: p.taxRate || 0,
            tags: p.tags ? p.tags.join(', ') : ''
        });
        setShowAddModal(true);
    };

    const handleAddSubmit = (e) => {
        e.preventDefault();
        if (!formData.name || !formData.sellingPrice || !formData.costPrice || !formData.sku) return;

        const parsedData = {
            ...formData,
            costPrice: parseFloat(formData.costPrice) || 0,
            sellingPrice: parseFloat(formData.sellingPrice) || 0,
            stock: parseInt(formData.stock) || 0,
            taxRate: parseFloat(formData.taxRate) || 0,
            tags: formData.tags.split(',').map(t => t.trim()).filter(t => t)
        };

        if (editingProduct) {
            updateProduct({ ...parsedData, id: editingProduct.id });
        } else {
            addProduct(parsedData);
        }

        setShowAddModal(false);
    };

    const [successStates, setSuccessStates] = useState({});

    const handleAdjust = (productId) => {
        const amt = parseInt(adjustAmounts[productId]) || 0;
        const reason = adjustReasons[productId] || "Inventory Adjustment";
        const source = adjustSources[productId] || (amt > 0 ? "IN-HOUSE" : "SALES");

        if (amt !== 0) {
            adjustStock(productId, amt, reason, source);
            setAdjustAmounts({ ...adjustAmounts, [productId]: '' });
            setAdjustReasons({ ...adjustReasons, [productId]: '' });
            setAdjustSources({ ...adjustSources, [productId]: 'IN-HOUSE' });
            
            // Visual feedback
            setSuccessStates({ ...successStates, [productId]: true });
            setTimeout(() => {
                setSuccessStates(prev => ({ ...prev, [productId]: false }));
            }, 1500);
        }
    };

    return (
        <>
        <div className="animate-fade-in flex flex-col gap-4">
            
            <div className="flex justify-between items-end pb-6 border-b border-black/5 text-ink-primary mb-2">
                <div>
                    <h1 className="text-6xl font-black tracking-tighter text-ink-primary mb-2 uppercase">Inventory.</h1>
                    <p className="text-ink-secondary font-medium uppercase tracking-tight text-sm opacity-50">Strategic Asset Management & Stock Control</p>
                </div>
                <div className="flex gap-6">
                    <button className="px-8 py-4 rounded-pill border border-black/10 font-bold text-ink-primary hover:bg-black/5 transition-all text-xs uppercase cursor-pointer tracking-widest" onClick={() => setShowHistoryModal(true)}>
                        <History size={16} className="inline mr-3 opacity-40" /> Movement Logs
                    </button>
                    {hasPermission('MANAGE_INVENTORY') && (
                        <button className="btn-signature group h-16" onClick={openAddModal}>
                            ADD ASSET
                            <div className="icon-nest">
                                <Plus size={20} className="group-hover:rotate-90 transition-transform duration-500" />
                            </div>
                        </button>
                    )}
                </div>
            </div>

            <div className="glass-panel !p-0 overflow-hidden !rounded-bento border-none shadow-premium">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-canvas border-b border-black/5">
                                <th className="px-6 py-2 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50">Product Details</th>
                                <th className="px-6 py-2 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50">Categorization</th>
                                <th className="px-6 py-2 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50 text-right">Unit Pricing</th>
                                <th className="px-6 py-2 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50 text-center">Infrastructure</th>
                                <th className="px-6 py-2 text-sm font-black uppercase tracking-widest text-ink-secondary opacity-50 text-right">Management</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-black/5">
                            {products.map((product, idx) => {
                                const isLow = product.stock > 0 && product.stock <= (businessProfile.lowStockThreshold || 10);
                                const isOut = product.stock <= 0;

                                return (
                                    <tr key={product.id} className="hover:bg-canvas transition-colors group">
                                        <td className="px-6 py-3">
                                            <div className="flex items-center gap-6">
                                                <div className="w-16 h-16 rounded-2xl bg-surface border border-black/5 shadow-premium flex items-center justify-center text-ink-primary shrink-0 overflow-hidden group-hover:bg-accent-signature group-hover:border-transparent transition-all">
                                                    {product.image ? (
                                                        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                                                    ) : (
                                                        <PackagePlus size={28} />
                                                    )}
                                                </div>
                                                <div>
                                                    <div className="text-base font-black text-ink-primary uppercase leading-none mb-2">{product.name}</div>
                                                    <div className="text-xs font-bold text-ink-secondary uppercase tracking-widest opacity-40">{product.sku}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-3">
                                            <div className="text-xs font-black text-ink-primary uppercase mb-2 tracking-tight">{product.category}</div>
                                            <div className="flex flex-wrap gap-2">
                                                {product.tags && product.tags.map(t => (
                                                    <span key={t} className="px-3 py-1.5 rounded-pill bg-canvas text-xs font-black text-ink-primary border border-black/5 uppercase tracking-widest">
                                                        {t}
                                                    </span>
                                                ))}
                                            </div>
                                        </td>
                                        <td className="px-6 py-3 text-right">
                                            <div className="text-base font-black text-ink-primary tracking-tighter">{businessProfile.currencySymbol}{product.sellingPrice.toFixed(2)}</div>
                                            <div className="text-sm font-bold text-ink-secondary uppercase tracking-widest opacity-40">Cost: {businessProfile.currencySymbol}{product.costPrice.toFixed(2)}</div>
                                        </td>
                                        <td className="px-6 py-3 text-center">
                                            <div className={`text-2xl font-black tracking-tighter ${isOut ? 'text-red-500' : isLow ? 'text-orange-400' : 'text-ink-primary'}`}>
                                                {product.stock}
                                            </div>
                                            <div className="text-sm font-black uppercase text-ink-secondary tracking-widest opacity-30">{product.unit}</div>
                                        </td>
                                        <td className="px-6 py-3 text-right">
                                            <div className="flex items-center justify-end gap-3 translate-x-4 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-500">
                                                {hasPermission('MANAGE_INVENTORY') && (
                                                    <>
                                                        <button 
                                                            onClick={() => openEditModal(product)}
                                                            className="w-12 h-12 rounded-pill bg-surface border border-black/5 flex items-center justify-center shadow-premium hover:bg-ink-primary hover:text-surface transition-all"
                                                        >
                                                            <Pencil size={16} />
                                                        </button>
                                                        <button 
                                                            onClick={() => {
                                                                 if (window.confirm(`Delete asset ${product.name}?`)) deleteProduct(product.id);
                                                            }}
                                                            className="w-12 h-12 rounded-pill bg-surface border border-red-100 flex items-center justify-center shadow-premium hover:bg-red-500 hover:text-white transition-all text-red-500"
                                                        >
                                                            <Trash2 size={16} />
                                                        </button>
                                                    </>
                                                )}
                                                <button 
                                                    onClick={() => handleAdjust(product.id, 1)}
                                                    className="w-12 h-12 rounded-pill bg-accent-signature flex items-center justify-center shadow-premium hover:scale-110 active:scale-95 transition-all"
                                                >
                                                    <Plus size={18} strokeWidth={4} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                            {products.length === 0 && (
                                <tr>
                                    <td colSpan="5" className="p-20 text-center">
                                        <div className="w-24 h-24 rounded-pill bg-canvas flex items-center justify-center mx-auto mb-6">
                                            <PackagePlus size={40} className="text-ink-primary opacity-10" />
                                        </div>
                                        <div className="text-sm font-black text-ink-primary uppercase tracking-widest">No Assets Detected</div>
                                        <div className="text-xs font-bold text-ink-secondary uppercase opacity-30 mt-2">Infrastructure is currently depleted</div>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {/* Add/Edit Product Modal */}
            {/* Add/Edit Product Modal */}
            {showAddModal && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[700px]">
                        <div className="flex justify-between items-start mb-16">
                            <div>
                                <h1 className="text-5xl font-black text-ink-primary tracking-tighter uppercase leading-none">Initialize Asset.</h1>
                                <p className="text-[11px] font-black text-ink-secondary uppercase tracking-[0.3em] mt-4 opacity-40">System configuration protocol alpha-v2</p>
                            </div>
                            <button className="w-14 h-14 rounded-pill bg-canvas flex items-center justify-center hover:scale-110 transition-all cursor-pointer text-ink-primary" onClick={() => setShowAddModal(false)}>
                                <X size={24} />
                            </button>
                        </div>

                        <form onSubmit={handleAddSubmit} className="grid grid-cols-2 gap-12">
                            <div className="col-span-2">
                                <label className="text-[10px] font-black text-ink-secondary uppercase tracking-widest mb-4 block opacity-60">Strategic Designation</label>
                                <input required type="text" className="w-full bg-canvas border-none rounded-2xl p-6 font-black text-ink-primary outline-none focus:ring-4 focus:ring-accent-signature/20 transition-all text-xl" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="e.g. HIGH-FIDELITY UNIT" />
                            </div>

                            <div>
                                <label className="text-[10px] font-black text-ink-secondary uppercase tracking-widest mb-4 block opacity-60">Authentication SKU</label>
                                <input required type="text" className="w-full bg-canvas border-none rounded-2xl p-6 font-black text-ink-primary outline-none" value={formData.sku} onChange={e => setFormData({ ...formData, sku: e.target.value })} placeholder="SKU-XXXXX" />
                            </div>

                            <div>
                                <label className="text-[10px] font-black text-ink-secondary uppercase tracking-widest mb-4 block opacity-60">Classification</label>
                                <select className="w-full bg-canvas border-none rounded-2xl p-6 font-black text-ink-primary outline-none appearance-none cursor-pointer" value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })}>
                                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                            </div>

                            <div className="col-span-2 bg-canvas p-8 rounded-bento border-2 border-dashed border-black/5 flex flex-col items-center justify-center gap-6">
                                {formData.sku ? (
                                    <div className="bg-surface p-10 rounded-2xl shadow-xl">
                                        <Barcode value={formData.sku} height={70} displayValue={true} background="transparent" lineColor="var(--color-ink-primary)" font="Inter" fontSize={18} textMargin={12} width={2.5} />
                                    </div>
                                ) : (
                                    <span className="text-[10px] font-black text-ink-primary/10 uppercase tracking-widest italic">Awaiting identification sequence...</span>
                                )}
                            </div>

                            <div className="col-span-1 p-8 rounded-bento bg-canvas border border-black/5">
                                <label className="text-[10px] font-black text-ink-secondary uppercase tracking-widest mb-5 block opacity-50">Unit Acquisition Cost</label>
                                <div className="flex items-center gap-3">
                                    <span className="text-3xl font-black text-ink-primary opacity-20">{businessProfile.currencySymbol}</span>
                                    <input required type="number" step="0.01" className="bg-transparent border-none w-full p-0 text-3xl font-black text-ink-primary outline-none" value={formData.costPrice} onChange={e => setFormData({ ...formData, costPrice: e.target.value })} />
                                </div>
                            </div>

                            <div className="col-span-1 p-8 rounded-bento bg-ink-primary shadow-premium">
                                <label className="text-[10px] font-black text-surface/40 uppercase tracking-widest mb-5 block opacity-50">Target Market Valuation</label>
                                <div className="flex items-center gap-3">
                                    <span className="text-3xl font-black text-surface opacity-20">{businessProfile.currencySymbol}</span>
                                    <input required type="number" step="0.01" className="bg-transparent border-none w-full p-0 text-3xl font-black text-accent-signature outline-none" value={formData.sellingPrice} onChange={e => setFormData({ ...formData, sellingPrice: e.target.value })} />
                                </div>
                            </div>

                            <div className="col-span-1">
                                <label className="text-[10px] font-black text-ink-secondary uppercase tracking-widest mb-4 block opacity-60">Standard Measurement</label>
                                <select className="w-full bg-canvas border-none rounded-2xl p-6 font-black text-ink-primary outline-none appearance-none cursor-pointer" value={formData.unit} onChange={e => setFormData({ ...formData, unit: e.target.value })}>
                                    {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                                </select>
                            </div>

                            <div className="col-span-1">
                                <label className="text-[10px] font-black text-ink-secondary uppercase tracking-widest mb-4 block opacity-60">Operational Inventory</label>
                                <input type="number" className="w-full bg-canvas border-none rounded-2xl p-6 font-black text-ink-primary outline-none" value={formData.stock} onChange={e => setFormData({ ...formData, stock: e.target.value })} />
                            </div>

                            <div className="col-span-2 grid grid-cols-2 gap-8 mt-16">
                                <button type="button" className="px-10 py-7 rounded-pill border border-black/10 font-black text-ink-primary text-xs uppercase tracking-[0.2em] hover:bg-black/5 transition-all cursor-pointer" onClick={() => setShowAddModal(false)}>Abort sequence</button>
                                <button type="submit" className="btn-signature !h-[84px] !text-base flex items-center justify-center p-0 !rounded-pill">
                                    {editingProduct ? 'Commit Configuration' : 'Initialize Asset'}
                                    <div className="icon-nest ml-6">
                                        <CheckCircle2 size={28} />
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Movement History Modal */}
            {showHistoryModal && (
                <div className="modal-overlay">
                    <div className="glass-modal !p-0 !max-w-[1200px] flex flex-col !rounded-bento overflow-hidden">
                        <div className="p-8 border-b border-black/5 flex justify-between items-center bg-canvas">
                            <div>
                                <h2 className="text-5xl font-black text-ink-primary uppercase tracking-tighter">Strategic Audit Log.</h2>
                                <p className="text-[11px] font-bold text-ink-secondary uppercase tracking-[0.3em] mt-4 opacity-40">Multi-vector Asset movement verification</p>
                            </div>
                            <button className="w-16 h-16 rounded-pill border border-black/10 flex items-center justify-center hover:bg-ink-primary hover:text-surface transition-all cursor-pointer text-ink-primary" onClick={() => setShowHistoryModal(false)}>
                                <X size={28} />
                            </button>
                        </div>

                        <div className="flex-1 overflow-y-auto p-8">
                            <table className="w-full text-left border-collapse">
                                <thead className="sticky top-0 z-10 bg-surface">
                                    <tr className="border-b-4 border-black/5">
                                        <th className="pb-6 text-[10px] font-black uppercase tracking-[0.3em] text-ink-secondary opacity-40">Chronological Index</th>
                                        <th className="pb-6 text-[10px] font-black uppercase tracking-[0.3em] text-ink-secondary opacity-40">Infrastructure Unit</th>
                                        <th className="pb-6 text-[10px] font-black uppercase tracking-[0.3em] text-ink-secondary opacity-40 text-center">Operation</th>
                                        <th className="pb-6 text-[10px] font-black uppercase tracking-[0.3em] text-ink-secondary opacity-40 text-center">Net Volume</th>
                                        <th className="pb-6 text-[10px] font-black uppercase tracking-[0.3em] text-ink-secondary opacity-40 text-right">Strategic Context</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-black/5">
                                    {(movementLog || []).map(log => (
                                        <tr key={log.id} className="hover:bg-canvas transition-colors">
                                            <td className="py-6 text-[10px] font-black text-ink-primary uppercase opacity-40">{new Date(log.date).toLocaleString()}</td>
                                            <td className="py-6">
                                                <div className="text-base font-black text-ink-primary uppercase tracking-tight">{log.productName}</div>
                                                <div className="text-sm font-bold text-ink-secondary uppercase tracking-widest opacity-30 mt-2">Source: {log.source || 'INTERNAL'}</div>
                                            </td>
                                            <td className="py-6 text-center">
                                                <span className={`px-5 py-2 rounded-pill text-xs font-black uppercase tracking-[0.2em] ${log.type === 'IN' ? 'bg-accent-signature/20 text-ink-primary border border-accent-signature/30' : 'bg-red-500 text-white shadow-premium'}`}>
                                                    {log.type === 'IN' ? 'Absorption' : 'Discharge'}
                                                </span>
                                            </td>
                                            <td className={`py-6 text-center font-black text-2xl tracking-tighter ${log.type === 'IN' ? 'text-lime-600' : 'text-red-500'}`}>
                                                {log.type === 'IN' ? '+' : '-'}{log.quantity}
                                            </td>
                                            <td className="py-6 text-right text-sm font-black text-ink-primary uppercase tracking-tight max-w-[200px] leading-relaxed italic opacity-70">
                                                "{log.reason}"
                                            </td>
                                        </tr>
                                    ))}
                                    {(movementLog || []).length === 0 && (
                                        <tr><td colSpan="5" className="p-40 text-center text-ink-secondary uppercase font-black text-xs tracking-[0.5em] opacity-10">Historical data zeroed</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

        </>
    );
};

export default Inventory;
