import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { Calendar, FileText, Download, Printer, TrendingUp, Package, Receipt, ArrowUpRight, ArrowDownRight, X, Check } from 'lucide-react';

const Reports = () => {
    const { 
        orders, movementLog, expenses, businessProfile, shops, users, vehicles, routes,
        getUserName, getVehicleName, hasPermission 
    } = useAppContext();
    const [dateRange, setDateRange] = useState('MONTH');
    const [activeTab, setActiveTab] = useState('SALES');
    const [invoiceOrder, setInvoiceOrder] = useState(null);

    // Filter Logic
    const filterByDate = (items, dateKey) => {
        if (dateRange === 'ALL') return items;
        const now = new Date();
        const past = new Date();

        if (dateRange === 'TODAY') past.setHours(0, 0, 0, 0);
        else if (dateRange === 'WEEK') past.setDate(now.getDate() - 7);
        else if (dateRange === 'MONTH') past.setMonth(now.getMonth() - 1);

        return items.filter(item => new Date(item[dateKey]) >= past);
    };

    const filteredOrders = useMemo(() => filterByDate(orders, 'date'), [orders, dateRange]);
    const filteredMovements = useMemo(() => filterByDate(movementLog, 'date'), [movementLog, dateRange]);
    const filteredExpenses = useMemo(() => filterByDate(expenses, 'date'), [expenses, dateRange]);

    // Sales Metrics
    const totalSalesVol = filteredOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    const cashSales = filteredOrders.filter(o => o.paymentMethod === 'CASH').reduce((sum, o) => sum + o.totalAmount, 0);
    const creditSales = filteredOrders.filter(o => o.paymentMethod === 'CREDIT').reduce((sum, o) => sum + o.totalAmount, 0);
    const totalCogs = filteredOrders.reduce((sum, o) => sum + (o.totalCogs || 0), 0);
    const grossMargin = totalSalesVol - totalCogs;

    // Movement Metrics
    const itemsIn = filteredMovements.filter(m => m.type === 'IN').reduce((sum, m) => sum + m.quantity, 0);
    const itemsOut = filteredMovements.filter(m => m.type === 'OUT').reduce((sum, m) => sum + m.quantity, 0);

    // Expense Metrics
    const totalExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);

    // Sales Attribution Metrics
    const attributionByRep = filteredOrders.reduce((acc, order) => {
        if (order.status !== 'CANCELLED' && order.bookedBy) {
            acc[order.bookedBy] = (acc[order.bookedBy] || 0) + order.totalAmount;
        }
        return acc;
    }, {});

    const attributionByFleet = filteredOrders.reduce((acc, order) => {
        if (order.status === 'COMPLETED' && order.deliveredBy) {
            acc[order.deliveredBy] = (acc[order.deliveredBy] || 0) + order.totalAmount;
        }
        return acc;
    }, {});

    const handlePrint = () => {
        window.print();
    };

    const handlePrintInvoice = () => {
        window.print();
    };

    const getClientName = (shopId) => {
        if (shopId === 'POS-WALKIN') return 'Walk-in Customer';
        const shop = shops.find(s => s.id === shopId);
        return shop ? shop.name : shopId;
    };

    return (
        <div className="animate-fade-in flex flex-col gap-8 pb-12 print-area">
            <div className="no-print flex flex-col md:flex-row justify-between items-start md:items-end pb-8 border-b border-black/5 gap-8">
                <div>
                    <h1 className="text-7xl font-black tracking-tighter text-ink-primary uppercase leading-none mb-4">Intelligence.</h1>
                    <p className="text-sm font-medium text-ink-secondary tracking-tight uppercase opacity-50">Strategic Data Analytics & Performance Audit Matrix</p>
                </div>
                <div className="flex gap-6 items-center flex-wrap">
                    <div className="pill-nav p-1 flex items-center gap-4 bg-canvas/50">
                        <Calendar size={18} className="text-ink-secondary ml-4 opacity-40" />
                        <select 
                            className="bg-transparent border-none font-black text-sm uppercase tracking-[0.2em] text-ink-primary outline-none py-3 pr-8 cursor-pointer appearance-none" 
                            value={dateRange} 
                            onChange={e => setDateRange(e.target.value)}
                        >
                            <option value="TODAY">Immediate Octant</option>
                            <option value="WEEK">7-Day Vector</option>
                            <option value="MONTH">30-Day Cycle</option>
                            <option value="ALL">Historical Archive</option>
                        </select>
                    </div>
                    {hasPermission('EXPORT_REPORTS') && (
                        <button className="btn-signature h-20 !text-base" onClick={handlePrint}>
                            PRINT AUDIT
                            <div className="icon-nest ml-6">
                                <Printer size={28} />
                            </div>
                        </button>
                    )}
                </div>
            </div>

            {/* Print Header */}
            <div className="print-only hidden mb-10 text-center">
                <h2 className="text-3xl font-black uppercase tracking-tighter">{businessProfile.name}</h2>
                <div className="text-[10px] font-bold uppercase tracking-widest opacity-40 mt-2">Strategic Performance Audit | Generated: {new Date().toLocaleDateString()}</div>
            </div>

            {/* Top Level KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="glass-panel p-6 flex flex-col justify-between min-h-[200px] group hover:scale-[1.02] transition-all duration-500 cursor-pointer bg-surface border-black/5 shadow-premium">
                    <div className="flex justify-between items-start mb-8">
                        <div className="w-16 h-16 rounded-3xl bg-ink-primary flex items-center justify-center text-surface shadow-2xl transition-all group-hover:scale-110">
                            <TrendingUp size={28} />
                        </div>
                        <span className="text-sm font-black uppercase tracking-[0.5em] text-ink-secondary opacity-40">Revenue.</span>
                    </div>
                    <div>
                        <div className="text-4xl font-black text-ink-primary tracking-tighter mb-4 leading-none">{businessProfile.currencySymbol}{totalSalesVol.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                        <div className="text-sm font-black text-accent-signature-hover uppercase tracking-widest flex items-center gap-2">
                            MARG: {businessProfile.currencySymbol}{grossMargin.toLocaleString()}
                            <div className="w-2 h-2 rounded-full bg-accent-signature shadow-lg shadow-accent-signature/40 animate-pulse"></div>
                        </div>
                    </div>
                </div>

                <div className="glass-panel p-6 flex flex-col justify-between min-h-[200px] group hover:scale-[1.02] transition-all duration-500 cursor-pointer bg-surface border-black/5 shadow-premium">
                    <div className="flex justify-between items-start mb-8">
                        <div className="w-16 h-16 rounded-3xl bg-canvas flex items-center justify-center text-ink-primary shadow-sm border border-black/5">
                            <FileText size={28} />
                        </div>
                        <span className="text-sm font-black uppercase tracking-[0.5em] text-ink-secondary opacity-40">Capital Split.</span>
                    </div>
                    <div>
                        <div className="flex flex-col gap-1">
                            <div className="flex items-center justify-between">
                                <span className="text-xl font-black text-accent-signature-hover font-mono">{businessProfile.currencySymbol}{cashSales.toLocaleString()}</span>
                                <span className="text-xs font-black uppercase text-ink-secondary opacity-40 tracking-widest">Liquid</span>
                            </div>
                            <div className="w-full h-1.5 bg-canvas rounded-full overflow-hidden">
                                <div className="h-full bg-accent-signature" style={{ width: `${(cashSales / (cashSales + creditSales + 1) * 100)}%` }}></div>
                            </div>
                            <div className="flex items-center justify-between mt-1">
                                <span className="text-xl font-black text-red-500 font-mono">{businessProfile.currencySymbol}{creditSales.toLocaleString()}</span>
                                <span className="text-xs font-black uppercase text-ink-secondary opacity-40 tracking-widest">Receivable</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="glass-panel p-6 flex flex-col justify-between min-h-[200px] group hover:scale-[1.02] transition-all duration-500 cursor-pointer bg-ink-primary !text-surface shadow-2xl">
                    <div className="flex justify-between items-start mb-8">
                        <div className="w-16 h-16 rounded-3xl bg-surface/10 flex items-center justify-center text-surface">
                            <Receipt size={28} />
                        </div>
                        <span className="text-sm font-black uppercase tracking-[0.5em] text-surface/40">Expenditure.</span>
                    </div>
                    <div>
                        <div className="text-4xl font-black text-surface tracking-tighter mb-4 leading-none">{businessProfile.currencySymbol}{totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                        <p className="text-sm font-black text-surface/40 uppercase tracking-widest">Operational Displacement</p>
                    </div>
                </div>

                <div className="glass-panel p-6 flex flex-col justify-between min-h-[200px] group hover:scale-[1.02] transition-all duration-500 cursor-pointer bg-surface border-black/5 shadow-premium">
                    <div className="flex justify-between items-start mb-8">
                        <div className="w-16 h-16 rounded-3xl bg-accent-signature flex items-center justify-center text-ink-primary shadow-lg group-hover:bg-ink-primary group-hover:text-accent-signature transition-colors">
                            <Package size={28} />
                        </div>
                        <span className="text-sm font-black uppercase tracking-[0.5em] text-ink-secondary opacity-40">Asset Velocity.</span>
                    </div>
                    <div className="flex flex-col gap-4">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-xl bg-green-50 flex items-center justify-center text-green-600">
                                    <ArrowDownRight size={16} />
                                </div>
                                <span className="text-lg font-black text-ink-primary">{itemsIn.toLocaleString()}</span>
                            </div>
                            <span className="text-xs font-black uppercase text-ink-secondary opacity-40 tracking-widest italic">Inbound</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-xl bg-red-50 flex items-center justify-center text-red-500">
                                    <ArrowUpRight size={16} />
                                </div>
                                <span className="text-lg font-black text-ink-primary">{itemsOut.toLocaleString()}</span>
                            </div>
                            <span className="text-xs font-black uppercase text-ink-secondary opacity-40 tracking-widest italic">Outbound</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Attribution Breakdown Cards */}
            <div className="no-print grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="glass-panel p-8 bg-surface border border-black/5 shadow-premium !rounded-bento">
                    <div className="flex justify-between items-center mb-8 border-b border-black/5 pb-4">
                        <h3 className="text-sm font-black uppercase tracking-[0.4em] text-ink-primary opacity-60">Personnel Yield Audit.</h3>
                        <div className="w-10 h-10 rounded-2xl bg-canvas flex items-center justify-center text-ink-primary shadow-sm">
                            <Users size={18} />
                        </div>
                    </div>
                    <div className="flex flex-col gap-4">
                        {Object.entries(attributionByRep).sort((a, b) => b[1] - a[1]).map(([repId, amount]) => (
                            <div key={repId} className="flex justify-between items-center p-4 bg-canvas/30 rounded-2xl group hover:bg-ink-primary transition-all duration-500 border border-black/5 shadow-sm">
                                <span className="text-sm font-black text-ink-primary uppercase tracking-widest group-hover:text-surface transition-colors">{getUserName(repId)}</span>
                                <span className="text-lg font-black text-ink-primary group-hover:text-accent-signature transition-colors">{businessProfile.currencySymbol}{amount.toLocaleString()}</span>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="glass-panel p-8 bg-ink-primary !text-surface shadow-2xl !rounded-bento relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-surface/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
                    <div className="flex justify-between items-center mb-8 border-b border-surface/10 pb-4 relative z-10">
                        <h3 className="text-sm font-black uppercase tracking-[0.4em] text-surface opacity-60">Infrastructure Yield Audit.</h3>
                        <div className="w-10 h-10 rounded-2xl bg-surface/10 flex items-center justify-center text-accent-signature">
                            <Truck size={18} />
                        </div>
                    </div>
                    <div className="flex flex-col gap-4 relative z-10">
                        {Object.entries(attributionByFleet).sort((a, b) => b[1] - a[1]).map(([routeId, amount]) => {
                            const route = routes.find(r => r.id === routeId);
                            const vehicleName = route ? getVehicleName(route.vehicleId) : 'CENTRAL CORE';
                            return (
                                <div key={routeId} className="flex justify-between items-center p-4 bg-surface/5 rounded-2xl hover:bg-surface/10 transition-all duration-500 border border-surface/5 shadow-sm">
                                    <div className="flex flex-col gap-1">
                                        <span className="text-sm font-black uppercase tracking-widest text-surface">{vehicleName}</span>
                                        {route && <span className="text-xs font-black text-surface/30 uppercase tracking-[0.3em]">{route.driverId}</span>}
                                    </div>
                                    <span className="text-lg font-black text-accent-signature">{businessProfile.currencySymbol}{amount.toLocaleString()}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="no-print pill-nav self-start">
                <button
                    onClick={() => setActiveTab('SALES')}
                    className={`px-10 py-4 rounded-pill text-[10px] font-black uppercase tracking-[0.2em] transition-all ${activeTab === 'SALES' ? 'bg-ink-primary text-surface shadow-premium' : 'text-ink-secondary hover:text-ink-primary'}`}
                >
                    Capital Ledger
                </button>
                <button
                    onClick={() => setActiveTab('MOVEMENTS')}
                    className={`px-10 py-4 rounded-pill text-[10px] font-black uppercase tracking-[0.2em] transition-all ${activeTab === 'MOVEMENTS' ? 'bg-ink-primary text-surface shadow-premium' : 'text-ink-secondary hover:text-ink-primary'}`}
                >
                    Asset Logistics
                </button>
                <button
                    onClick={() => setActiveTab('EXPENSES')}
                    className={`px-10 py-4 rounded-pill text-[10px] font-black uppercase tracking-[0.2em] transition-all ${activeTab === 'EXPENSES' ? 'bg-ink-primary text-surface shadow-premium' : 'text-ink-secondary hover:text-ink-primary'}`}
                >
                    Operating Costs
                </button>
            </div>

            {/* Table Content */}
            <div className="glass-panel !p-0 overflow-hidden border border-black/5 bg-surface shadow-premium !rounded-bento">
                <div className="overflow-x-auto">
                    {activeTab === 'SALES' && (
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-canvas border-b border-black/5">
                                    <th className="p-6 text-sm font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Index / Counterparty</th>
                                    <th className="p-6 text-sm font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Transmission Model</th>
                                    <th className="p-6 text-sm font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50 text-center">Audit Status</th>
                                    <th className="p-6 text-sm font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50 text-right">Net Yield</th>
                                    <th className="no-print p-6 text-sm font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50 text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-black/5 bg-surface">
                                {filteredOrders.map(order => (
                                    <tr key={order.id} className="hover:bg-canvas transition-all duration-300 group">
                                        <td className="p-10">
                                            <div className="text-base font-black text-ink-primary uppercase tracking-tight leading-none mb-2">{order.id}</div>
                                            <div className="text-[10px] font-black text-ink-secondary uppercase opacity-40 tracking-[0.2em]">{order.customerInfo?.name || 'GENERIC UNIT'}</div>
                                        </td>
                                        <td className="p-10">
                                            <span className={`px-5 py-2 rounded-pill text-[10px] font-black uppercase tracking-widest ${order.paymentMethod === 'CASH' ? 'bg-accent-signature text-ink-primary border border-ink-primary/10' : 'bg-ink-primary text-surface shadow-lg'}`}>
                                                {order.paymentMethod}
                                            </span>
                                        </td>
                                        <td className="p-10 text-center">
                                            <div className="flex items-center justify-center gap-3">
                                                <div className={`w-3 h-3 rounded-full ${order.status === 'COMPLETED' ? 'bg-accent-signature shadow-lg shadow-accent-signature/40' : 'bg-red-500 shadow-lg shadow-red-500/40'} animate-pulse`}></div>
                                                <span className="text-[10px] font-black text-ink-primary uppercase tracking-[0.2em] opacity-60">{order.status || 'COMPLETED'}</span>
                                            </div>
                                        </td>
                                        <td className="p-10 text-right text-base font-black text-ink-primary">
                                            {businessProfile.currencySymbol}{order.totalAmount.toLocaleString()}
                                        </td>
                                        <td className="no-print p-10 text-right">
                                            <div className="flex justify-end opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-4 group-hover:translate-x-0">
                                                {hasPermission('PRINT_INVOICE') && (
                                                    <button 
                                                        className="px-6 py-3 rounded-pill border border-black/10 text-[10px] font-black uppercase tracking-widest text-ink-primary hover:bg-ink-primary hover:text-accent-signature transition-all shadow-premium bg-surface" 
                                                        onClick={() => setInvoiceOrder(order)}
                                                    >
                                                        VIEW VOUCHER
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}

                    {activeTab === 'MOVEMENTS' && (
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-canvas border-b border-black/5">
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Chronological Index</th>
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Asset Unit</th>
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Delta Vector</th>
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50 text-right">Audit Context</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-black/5 bg-surface">
                                {filteredMovements.map(log => (
                                    <tr key={log.id} className="hover:bg-canvas transition-all duration-300">
                                        <td className="p-10">
                                            <div className="text-base font-black text-ink-primary uppercase leading-none mb-2">{new Date(log.date).toLocaleDateString()}</div>
                                            <div className="text-[10px] font-black text-ink-secondary uppercase opacity-30 tracking-[0.2em]">{new Date(log.date).toLocaleTimeString()}</div>
                                        </td>
                                        <td className="p-10">
                                            <div className="text-base font-black text-ink-primary uppercase tracking-tight mb-3">{log.productName}</div>
                                            <span className={`px-5 py-2 rounded-pill text-[10px] font-black uppercase tracking-widest border ${log.type === 'IN' ? 'bg-green-50 text-green-700 border-green-100' : 'bg-red-50 text-red-600 border-red-100 shadow-sm'}`}>
                                                {log.type} PROTOCOL
                                            </span>
                                        </td>
                                        <td className="p-10">
                                            <div className={`text-4xl font-black tracking-tighter ${log.type === 'IN' ? 'text-accent-signature-hover' : 'text-red-500'}`}>
                                                {log.type === 'IN' ? '+' : '-'}{log.quantity.toLocaleString()}
                                            </div>
                                        </td>
                                        <td className="p-10 text-right">
                                            <div className="text-[10px] font-black text-ink-secondary uppercase italic max-w-[300px] ml-auto leading-relaxed border-l-4 border-black/5 pl-6 opacity-60">
                                                "{log.reason}"
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}

                    {activeTab === 'EXPENSES' && (
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-canvas border-b border-black/5">
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Disbursement Index</th>
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Classification</th>
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50">Strategic Purpose</th>
                                    <th className="p-10 text-[10px] font-black uppercase tracking-[0.4em] text-ink-secondary opacity-50 text-right">Value Displacement</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-black/5 bg-surface">
                                {filteredExpenses.map(expense => (
                                    <tr key={expense.id} className="hover:bg-canvas transition-all duration-300">
                                        <td className="p-10">
                                            <div className="text-base font-black text-ink-primary uppercase leading-none mb-2">{new Date(expense.date).toLocaleDateString()}</div>
                                            <div className="text-[10px] font-black text-ink-secondary uppercase opacity-20 tracking-[0.2em]">{expense.id.slice(0, 12)}</div>
                                        </td>
                                        <td className="p-10">
                                            <span className="px-6 py-3 rounded-2xl bg-ink-primary text-surface text-[10px] font-black uppercase tracking-[0.2em] shadow-lg border border-surface/5">
                                                {expense.category}
                                            </span>
                                        </td>
                                        <td className="p-10">
                                            <div className="text-sm font-black text-ink-primary uppercase tracking-tight mb-2">{expense.description}</div>
                                            {expense.routeId && (
                                                <div className="flex items-center gap-3">
                                                    <div className="w-2 h-2 rounded-full bg-accent-signature animate-pulse"></div>
                                                    <span className="text-[9px] font-black text-ink-secondary uppercase tracking-widest opacity-40">Logical Hub: {expense.routeId.slice(-6)}</span>
                                                </div>
                                            )}
                                        </td>
                                        <td className="p-10 text-right">
                                            <div className="text-3xl font-black text-red-500 tracking-tighter">
                                                -{businessProfile.currencySymbol}{expense.amount.toLocaleString()}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>

            {/* ========== VOUCHER MODAL ========== */}
            {invoiceOrder && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[850px] !p-0 !overflow-hidden flex flex-col bg-surface border border-black/5 shadow-2xl !rounded-[60px]">
                        <div id="invoice-print-area" className="p-16 overflow-y-auto flex-1 custom-scrollbar">
                            <div className="flex justify-between items-start mb-20 border-b-[12px] border-ink-primary pb-12">
                                <div>
                                    <h2 className="text-8xl font-black text-ink-primary uppercase tracking-tighter leading-none mb-6">VOUCHER.</h2>
                                    <div className="flex items-center gap-4">
                                        <div className="w-12 h-3 bg-accent-signature rounded-full"></div>
                                        <p className="text-[10px] font-black text-ink-secondary uppercase tracking-[0.6em] opacity-40">Financial Settlement Protocol</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="text-3xl font-black text-ink-primary uppercase tracking-tighter leading-none mb-4">{businessProfile.name}</div>
                                    <div className="text-[10px] font-black text-ink-secondary uppercase tracking-widest opacity-40 leading-relaxed">
                                        {new Date(invoiceOrder.date).toLocaleDateString()} <br />
                                        {new Date(invoiceOrder.date).toLocaleTimeString()}
                                    </div>
                                    <div className="mt-8 px-6 py-3 bg-ink-primary text-surface inline-block rounded-2xl font-black tracking-tighter text-sm shadow-xl">
                                        {invoiceOrder.id}
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-12 mb-20 bg-canvas/50 p-12 rounded-[50px] border border-black/5">
                                <div>
                                    <div className="text-[10px] font-black text-ink-secondary uppercase tracking-[0.4em] mb-6 opacity-30">Counterparty Entity</div>
                                    <div className="text-4xl font-black text-ink-primary uppercase tracking-tighter leading-tight mb-3">
                                        {invoiceOrder.customerInfo?.name || 'GENERIC CLIENT'}
                                    </div>
                                    <div className="text-xs font-black text-ink-secondary uppercase tracking-widest opacity-60 leading-relaxed">
                                        Registry: {getClientName(invoiceOrder.shopId)} <br />
                                        {invoiceOrder.customerInfo?.phone && `Uplink: ${invoiceOrder.customerInfo.phone}`}
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="text-[10px] font-black text-ink-secondary uppercase tracking-[0.4em] mb-6 opacity-30">Strategic Authorization</div>
                                    <div className="text-4xl font-black text-ink-primary uppercase tracking-tighter opacity-80 mb-6">
                                        {invoiceOrder.paymentMethod} SETTLEMENT
                                    </div>
                                    <div className={`px-8 py-3 rounded-pill text-xs font-black uppercase tracking-widest shadow-premium ${invoiceOrder.status === 'COMPLETED' ? 'bg-accent-signature text-ink-primary border border-ink-primary/5' : 'bg-red-500 text-surface rotate-2'}`}>
                                        {invoiceOrder.status || 'VERIFIED'}
                                    </div>
                                </div>
                            </div>

                            <table className="w-full text-left mb-20 border-collapse">
                                <thead>
                                    <tr className="border-b-4 border-ink-primary">
                                        <th className="py-6 text-[10px] font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40">ID</th>
                                        <th className="py-6 text-[10px] font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40">Asset Allocation</th>
                                        <th className="py-6 text-[10px] font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40 text-center">Vol.</th>
                                        <th className="py-6 text-right text-[10px] font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40">Unit Value</th>
                                        <th className="py-6 text-right text-[10px] font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40 text-ink-primary !opacity-100">Cumulative Value</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-black/5">
                                    {invoiceOrder.items.map((item, idx) => {
                                        const lineGross = item.price * item.quantity;
                                        const lineDiscount = lineGross * ((item.discount || 0) / 100);
                                        const afterDiscount = lineGross - lineDiscount;
                                        const lineTax = afterDiscount * ((item.taxRate || 0) / 100);
                                        const lineTotal = afterDiscount + lineTax;
                                        return (
                                            <tr key={item.productId || idx} className="hover:bg-canvas/30 transition-colors">
                                                <td className="py-8 text-xs font-black text-ink-primary opacity-20">{String(idx + 1).padStart(2, '0')}</td>
                                                <td className="py-8">
                                                    <div className="text-base font-black text-ink-primary uppercase tracking-tight leading-none mb-2">{item.name}</div>
                                                    <div className="text-[10px] font-black text-ink-secondary uppercase tracking-[0.2em] opacity-30 italic">{item.sku}</div>
                                                </td>
                                                <td className="py-8 text-center font-black text-base text-ink-primary">{item.quantity}</td>
                                                <td className="py-8 text-right font-black text-sm text-ink-secondary opacity-60 font-mono">{businessProfile.currencySymbol}{item.price.toFixed(2)}</td>
                                                <td className="py-8 text-right font-black text-base text-ink-primary font-mono">{businessProfile.currencySymbol}{lineTotal.toFixed(2)}</td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>

                            <div className="max-w-[400px] ml-auto">
                                <div className="space-y-4 mb-8">
                                    <div className="flex justify-between items-center px-4">
                                        <span className="text-[10px] font-black text-ink-secondary uppercase tracking-[0.3em] opacity-40">Sub-Displacement</span>
                                        <span className="text-lg font-black text-ink-primary font-mono">{businessProfile.currencySymbol}{invoiceOrder.subtotal.toFixed(2)}</span>
                                    </div>
                                    {invoiceOrder.tax > 0 && (
                                        <div className="flex justify-between items-center px-4">
                                            <span className="text-[10px] font-black text-ink-secondary uppercase tracking-[0.3em] opacity-40">System Tax Vector</span>
                                            <span className="text-lg font-black text-ink-primary font-mono">+{businessProfile.currencySymbol}{invoiceOrder.tax.toFixed(2)}</span>
                                        </div>
                                    )}
                                </div>
                                <div className="p-10 bg-ink-primary rounded-[40px] shadow-2xl flex justify-between items-center">
                                    <span className="text-sm font-black text-surface/40 uppercase tracking-[0.3em]">Net Capital Value</span>
                                    <span className="text-4xl font-black text-accent-signature tracking-tighter font-mono">{businessProfile.currencySymbol}{invoiceOrder.totalAmount.toFixed(2)}</span>
                                </div>
                            </div>
                        </div>

                        <div className="p-12 bg-canvas/50 no-print flex gap-8 border-t border-black/5">
                            <button className="flex-1 py-7 rounded-pill border border-black/10 font-black text-ink-primary text-xs uppercase tracking-widest hover:bg-black/5 transition-all shadow-sm bg-surface" onClick={() => setInvoiceOrder(null)}>Return to Archive</button>
                            <button className="flex-[2.5] btn-signature group !h-[86px] !text-lg" onClick={handlePrintInvoice}>
                                EXECUTE PRINT MANDATE
                                <div className="icon-nest ml-6">
                                    <Printer size={32} />
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <style>{`
                @media print {
                    body * { visibility: hidden; }
                    #invoice-print-area, #invoice-print-area * { visibility: visible; }
                    #invoice-print-area { position: absolute; left: 0; top: 0; width: 100%; padding: 0 !important; }
                    .no-print { display: none !important; }
                    .print-only { display: block !important; }
                }
            `}</style>
        </div>
    );
};

export default Reports;
