import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { 
    UserCircle, Plus, DollarSign, Building, Phone, MapPin, 
    Edit3, Trash2, X, Check, Save, UserCheck, CreditCard, 
    ChevronRight, ExternalLink, ShieldCheck, Mail
} from 'lucide-react';

const Clients = () => {
    const { shops, addShop, updateShop, deleteShop, orders, businessProfile, isViewOnly, hasPermission } = useAppContext();
    const [isAdding, setIsAdding] = useState(false);
    const [editingClient, setEditingClient] = useState(null);
    const [formData, setFormData] = useState({ name: '', contact: '', phone: '', address: '' });
    const [deleteConfirm, setDeleteConfirm] = useState(null);

    const clientStats = useMemo(() => {
        const stats = {};
        shops.forEach(s => stats[s.id] = { totalSales: 0, outstandingDebt: 0, orderCount: 0 });

        orders.forEach(order => {
            if (stats[order.shopId]) {
                stats[order.shopId].totalSales += order.totalAmount;
                stats[order.shopId].orderCount += 1;
                if (order.paymentMethod === 'CREDIT') {
                    stats[order.shopId].outstandingDebt += order.totalAmount;
                }
            }
        });
        return stats;
    }, [orders, shops]);

    const openAdd = () => {
        setEditingClient(null);
        setFormData({ name: '', contact: '', phone: '', address: '' });
        setIsAdding(true);
    };

    const openEdit = (client) => {
        setEditingClient(client);
        setFormData({ name: client.name, contact: client.contact, phone: client.phone, address: client.address });
        setIsAdding(true);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (editingClient) {
            updateShop({ ...editingClient, ...formData });
        } else {
            addShop(formData);
        }
        setIsAdding(false);
        setEditingClient(null);
        setFormData({ name: '', contact: '', phone: '', address: '' });
    };

    const handleDelete = (shopId) => {
        deleteShop(shopId);
        setDeleteConfirm(null);
    };

    return (
        <div className="animate-fade-in flex flex-col gap-8 pb-12">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 pb-8 border-b border-black/5">
                <div>
                    <h1 className="text-6xl font-black tracking-tighter text-ink-primary leading-none mb-4">Network.</h1>
                    <p className="text-sm font-medium text-ink-secondary tracking-tight uppercase opacity-50">CRM & Capital Vulnerability Tracking</p>
                </div>
                <div className="flex items-center gap-6">
                    <div className="text-right mr-4">
                        <div className="text-sm font-black uppercase tracking-[0.2em] text-ink-secondary opacity-40 mb-1">Active Accounts</div>
                        <div className="text-4xl font-black text-ink-primary tracking-tighter">{shops.length} Units</div>
                    </div>
                    {hasPermission('ADD_CLIENT') && (
                        <button className="btn-signature h-16" onClick={openAdd}>
                            NEW ACCOUNT
                            <div className="icon-nest">
                                <Plus size={20} />
                            </div>
                        </button>
                    )}
                </div>
            </div>

            {/* Registration Overlay / Form */}
            {isAdding && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[650px] !overflow-hidden">
                        <button 
                            onClick={() => { setIsAdding(false); setEditingClient(null); }}
                            className="absolute top-8 right-8 w-12 h-12 rounded-pill bg-canvas flex items-center justify-center text-ink-primary hover:scale-110 transition-transform z-10"
                        >
                            <X size={20} />
                        </button>

                        <div className="absolute top-0 left-0 w-2 h-full bg-[#C8F135]"></div>

                        <div className="mb-8">
                            <h3 className="text-4xl font-black tracking-tighter text-ink-primary uppercase mb-2">
                                {editingClient ? 'Edit Profile' : 'Onboarding'}
                            </h3>
                            <p className="text-sm font-bold text-ink-secondary uppercase tracking-widest opacity-40">Client Infrastructure Update</p>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="md:col-span-2">
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Institutional Identity</label>
                                    <input 
                                        required 
                                        type="text" 
                                        placeholder="Business / Institution Name..."
                                        className="input-field !rounded-2xl !py-5 font-black text-xl" 
                                        value={formData.name} 
                                        onChange={e => setFormData({...formData, name: e.target.value})} 
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Primary Contact</label>
                                    <input 
                                        required 
                                        type="text" 
                                        className="input-field !rounded-2xl !py-5 font-bold" 
                                        placeholder="Full Name..."
                                        value={formData.contact} 
                                        onChange={e => setFormData({...formData, contact: e.target.value})} 
                                    />
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Tele-Communication</label>
                                    <input 
                                        required 
                                        type="text" 
                                        className="input-field !rounded-2xl !py-5 font-bold" 
                                        placeholder="+1 (000) 000-0000"
                                        value={formData.phone} 
                                        onChange={e => setFormData({...formData, phone: e.target.value})} 
                                    />
                                </div>

                                <div className="md:col-span-2">
                                    <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-50 mb-3">Geographic Coordinate (Address)</label>
                                    <input 
                                        required 
                                        type="text" 
                                        className="input-field !rounded-2xl !py-5 font-medium" 
                                        placeholder="Full Physical Location..."
                                        value={formData.address} 
                                        onChange={e => setFormData({...formData, address: e.target.value})} 
                                    />
                                </div>
                            </div>

                            <div className="flex gap-4 pt-6">
                                <button type="button" className="flex-1 py-6 rounded-pill border border-black/10 font-bold text-ink-primary hover:bg-black/5 transition-all text-xs tracking-widest uppercase" onClick={() => { setIsAdding(false); setEditingClient(null); }}>Abort</button>
                                <button type="submit" className="btn-signature flex-[2] !py-6 !rounded-pill">
                                    {editingClient ? 'AUTHORIZE UPDATE' : 'AUTHORIZE ACCOUNT'}
                                    <div className="icon-nest">
                                        <Save size={20} />
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Client Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {shops.map(client => {
                    const stats = clientStats[client.id];
                    return (
                        <div key={client.id} className="glass-panel !p-0 !rounded-bento overflow-hidden border border-black/5 hover:shadow-premium transition-all flex flex-col group">
                            {/* Card Header */}
                            <div className="p-6 pb-4 flex justify-between items-start">
                                <div className="flex items-center gap-5">
                                    <div className="w-16 h-16 rounded-2xl bg-ink-primary text-accent-signature flex items-center justify-center shrink-0 shadow-lg">
                                        <Building size={28} />
                                    </div>
                                    <div className="min-w-0">
                                        <h3 className="text-2xl font-black text-ink-primary uppercase tracking-tighter truncate leading-tight">{client.name}</h3>
                                        <div className="text-xs font-bold text-ink-secondary uppercase tracking-widest opacity-40">#{client.id.split('-').pop()}</div>
                                    </div>
                                </div>
                                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    {hasPermission('EDIT_CLIENT') && (
                                        <button onClick={() => openEdit(client)} className="w-12 h-12 rounded-2xl bg-white border border-black/5 shadow-sm flex items-center justify-center text-ink-primary hover:bg-accent-signature transition-all">
                                            <Edit3 size={18} />
                                        </button>
                                    )}
                                    {hasPermission('DELETE_CLIENT') && (
                                        <button 
                                            onClick={() => { if(window.confirm('Terminate client relationship record?')) handleDelete(client.id); }}
                                            className="w-12 h-12 rounded-2xl bg-white border border-black/5 shadow-sm flex items-center justify-center text-red-500 hover:bg-red-50 transition-all"
                                        >
                                            <Trash2 size={18} />
                                        </button>
                                    )}
                                </div>
                            </div>

                            {/* Contact Details */}
                            <div className="px-6 py-6 space-y-4">
                                <div className="flex items-center gap-3 text-sm font-bold text-ink-primary uppercase tracking-tight">
                                    <UserCircle size={16} className="text-ink-secondary opacity-30" />
                                    {client.contact}
                                </div>
                                <div className="flex items-center gap-3 text-sm font-bold text-ink-primary uppercase tracking-tight">
                                    <Phone size={16} className="text-ink-secondary opacity-30" />
                                    {client.phone}
                                </div>
                                <div className="flex items-center gap-3 text-sm font-medium text-ink-secondary uppercase tracking-tighter opacity-70">
                                    <MapPin size={16} className="text-ink-secondary opacity-30 shrink-0" />
                                    <span className="truncate">{client.address}</span>
                                </div>
                            </div>

                            {/* Metrics Section */}
                            <div className="mt-auto bg-canvas p-6 grid grid-cols-3 gap-6 border-t border-black/5">
                                <div>
                                    <div className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-40 mb-3">Orders</div>
                                    <div className="text-2xl font-black text-ink-primary tracking-tighter">{stats?.orderCount || 0}</div>
                                </div>
                                <div>
                                    <div className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-40 mb-3">Lifetime</div>
                                    <div className="text-2xl font-black text-green-600 tracking-tighter">
                                        {businessProfile.currencySymbol}{Math.round(stats?.totalSales || 0)}
                                    </div>
                                </div>
                                <div>
                                    <div className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-40 mb-3">Liability</div>
                                    <div className={`text-2xl font-black tracking-tighter ${stats?.outstandingDebt > 0 ? 'text-red-500' : 'text-ink-primary opacity-20'}`}>
                                        {businessProfile.currencySymbol}{Math.round(stats?.outstandingDebt || 0)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}

                {shops.length === 0 && (
                    <div className="col-span-full py-32 text-center opacity-10">
                        <UserCheck size={80} strokeWidth={1} />
                        <p className="text-sm font-black uppercase tracking-[0.4em] mt-8">Empty Sector: Initiate Onboarding</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Clients;
