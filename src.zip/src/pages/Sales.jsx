import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { 
    ShoppingCart as CartIcon, Search, Plus, Minus, FileText, User, 
    Truck, BadgeDollarSign, Percent, Clock, X, CreditCard, 
    Banknote, Printer, Check, ArrowRight, Package, Grid3X3 
} from 'lucide-react';

const Sales = () => {
    const { products, businessProfile, placeOrder, routes, orders, shops, isViewOnly } = useAppContext();
    const [selectedShopId, setSelectedShopId] = useState('WALKIN');
    const [customerInfo, setCustomerInfo] = useState({ name: 'Walk-in Customer', phone: '' });
    const [cart, setCart] = useState([]);
    const [selectedRoute, setSelectedRoute] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [orderComplete, setOrderComplete] = useState(false);
    const [lastOrderId, setLastOrderId] = useState(null);
    const [lastOrderTotal, setLastOrderTotal] = useState(0);
    
    // Modal & Status State
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [pendingPaymentMethod, setPendingPaymentMethod] = useState('CASH');
    
    // UI State
    const [mobileCartOpen, setMobileCartOpen] = useState(false);
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [customerSearch, setCustomerSearch] = useState('');
    const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
    const [scheduledDate, setScheduledDate] = useState(new Date(Date.now() + 86400000).toISOString().split('T')[0]); 
    const [showBookingDateModal, setShowBookingDateModal] = useState(false);

    useEffect(() => {
        const handler = () => setIsMobile(window.innerWidth < 768);
        window.addEventListener('resize', handler);
        return () => window.removeEventListener('resize', handler);
    }, []);

    const activeRoutes = (routes || []).filter(r => r.status === 'ACTIVE');

    // Clear cart if route changes
    useEffect(() => { setCart([]); }, [selectedRoute]);

    const availableProducts = useMemo(() => {
        if (!selectedRoute) return (products || []).filter(p => p.stock > 0);
        
        const route = (routes || []).find(r => r.id === selectedRoute);
        if (!route) return [];

        const routeSales = (orders || []).filter(o => o.routeId === route.id);
        const soldMap = {};
        routeSales.forEach(order => {
            (order.items || []).forEach(item => {
                soldMap[item.productId] = (soldMap[item.productId] || 0) + item.quantity;
            });
        });

        return (route.loadedStock || []).map(item => {
            const sold = soldMap[item.productId] || 0;
            const left = item.quantity - sold;
            if (left > 0) {
                const productRef = products.find(p => p.id === item.productId);
                return { ...productRef, stock: left };
            }
            return null;
        }).filter(p => p !== null);
    }, [products, routes, orders, selectedRoute]);

    const categories = useMemo(() => {
        const cats = [...new Set(availableProducts.map(p => p.category))];
        return ['All', ...cats.sort()];
    }, [availableProducts]);

    const filteredProducts = useMemo(() => {
        let filtered = availableProducts;
        if (selectedCategory !== 'All') {
            filtered = filtered.filter(p => p.category === selectedCategory);
        }
        if (searchTerm) {
            const lowerSearch = searchTerm.toLowerCase();
            filtered = filtered.filter(p =>
                p.name.toLowerCase().includes(lowerSearch) ||
                p.sku.toLowerCase().includes(lowerSearch) ||
                p.category.toLowerCase().includes(lowerSearch)
            );
        }
        return filtered;
    }, [availableProducts, searchTerm, selectedCategory]);

    const filteredCustomers = useMemo(() => {
        if (!customerSearch) return shops;
        const lower = customerSearch.toLowerCase();
        return (shops || []).filter(s => 
            s.name.toLowerCase().includes(lower) || 
            (s.phone && s.phone.includes(lower))
        );
    }, [shops, customerSearch]);

    const addToCart = (product) => {
        const existing = cart.find(item => item.productId === product.id);
        if (existing) {
            if (existing.quantity < product.stock) {
                setCart(cart.map(item => item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item));
            }
        } else {
            setCart([...cart, {
                productId: product.id,
                quantity: 1,
                price: product.sellingPrice,
                sellingPrice: product.sellingPrice,
                discount: 0,
                taxRate: product.taxRate || 0,
                name: product.name,
                sku: product.sku
            }]);
        }
    };

    const removeFromCart = (productId) => {
        const existing = cart.find(item => item.productId === productId);
        if (existing.quantity > 1) {
            setCart(cart.map(item => item.productId === productId ? { ...item, quantity: item.quantity - 1 } : item));
        } else {
            setCart(cart.filter(item => item.productId !== productId));
        }
    };

    const updateCartItem = (productId, field, value) => {
        setCart(cart.map(item => {
            if (item.productId !== productId) return item;
            const updated = { ...item, [field]: value };
            if (field === 'quantity') {
                const product = products.find(p => p.id === productId);
                const maxStock = product ? product.stock : 9999;
                updated.quantity = Math.max(1, Math.min(parseInt(value) || 1, maxStock));
            }
            if (field === 'price') updated.price = Math.max(0, parseFloat(value) || 0);
            if (field === 'discount') updated.discount = Math.max(0, Math.min(100, parseFloat(value) || 0));
            return updated;
        }));
    };

    const cartCalc = useMemo(() => {
        let subtotal = 0;
        let totalDiscount = 0;
        let totalTax = 0;

        const lines = cart.map(item => {
            const lineGross = (item.price || 0) * (item.quantity || 0);
            const lineDiscount = lineGross * ((item.discount || 0) / 100);
            const afterDiscount = lineGross - lineDiscount;
            const lineTax = afterDiscount * ((item.taxRate || 0) / 100);
            
            subtotal += lineGross;
            totalDiscount += lineDiscount;
            totalTax += lineTax;

            return { ...item, lineGross, lineDiscount, afterDiscount, lineTax, lineTotal: afterDiscount + lineTax };
        });

        const finalTotal = subtotal - totalDiscount + totalTax;
        return { lines, subtotal, totalDiscount, totalTax, finalTotal, totalItems: cart.reduce((sum, item) => sum + item.quantity, 0) };
    }, [cart]);

    const handleConfirmTransaction = (statusOverride) => {
        const status = statusOverride || 'COMPLETED';
        const orderId = placeOrder(
            selectedShopId === 'WALKIN' ? 'POS-WALKIN' : selectedShopId,
            cart,
            cartCalc.subtotal,
            cartCalc.totalDiscount,
            cartCalc.totalTax,
            cartCalc.finalTotal,
            customerInfo,
            pendingPaymentMethod,
            selectedRoute || null,
            status,
            status === 'PENDING' ? scheduledDate : null
        );
        setLastOrderId(orderId);
        setLastOrderTotal(cartCalc.finalTotal);
        setCart([]);
        setSelectedShopId('WALKIN');
        setCustomerInfo({ name: 'Walk-in Customer', phone: '' });
        setShowPaymentModal(false);
        setShowBookingDateModal(false);
        setOrderComplete(true);
    };

    if (orderComplete) {
        return (
            <div className="animate-fade-in flex flex-col items-center justify-center min-h-[70vh]">
                <div className="glass-panel max-w-[500px] w-full text-center p-12 border-none">
                    <div className="flex justify-center mb-8">
                        <div className="bg-[#C8F135]/20 p-6 rounded-full text-[#111]">
                            <Check size={64} strokeWidth={3} />
                        </div>
                    </div>
                    <div className="p-8 bg-canvas rounded-bento border border-black/5 mb-8 text-center">
                        <div className="text-sm font-black uppercase tracking-[0.4em] text-ink-secondary mb-3 opacity-40">Total Capital Processed</div>
                        <div className="text-6xl font-black text-ink-primary tracking-tighter">
                            {businessProfile?.currencySymbol || '$'}{lastOrderTotal.toLocaleString()}
                        </div>
                    </div>

                    <div className="flex gap-6">
                        <button className="flex-1 py-6 rounded-pill border border-black/10 font-black text-ink-primary hover:bg-black/5 transition-all flex items-center justify-center gap-3 text-xs uppercase" onClick={() => window.print()}>
                            <Printer size={20} /> PRINT RECEIPT
                        </button>
                        <button className="btn-signature flex-1 !h-20" onClick={() => setOrderComplete(false)}>
                            NEW ORDER
                            <div className="icon-nest">
                                <ArrowRight size={22} />
                            </div>
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    const renderCartPanel = () => (
        <div className="flex flex-col h-full bg-surface lg:bg-transparent">
            <div className="p-6 border-b border-black/5 flex justify-between items-center bg-surface/50 backdrop-blur-3xl sticky top-0 z-10">
                <h2 className="text-2xl font-black tracking-tighter text-ink-primary uppercase flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-ink-primary text-accent-signature flex items-center justify-center shadow-lg">
                        <CartIcon size={24} />
                    </div>
                    Cart.
                </h2>
                {isMobile && <button onClick={() => setMobileCartOpen(false)} className="text-ink-primary opacity-30 hover:opacity-100 transition-opacity"><X size={28} /></button>}
            </div>

            {/* Customer Section */}
            <div className="p-6 border-b border-black/5 bg-canvas/30">
                <div className="mb-6">
                    <label className="block text-sm font-black uppercase tracking-[0.3em] text-ink-secondary opacity-50 mb-4">Target Personnel</label>
                    <div className="relative">
                        <User size={18} className="absolute left-6 top-1/2 -translate-y-1/2 text-ink-primary opacity-20" />
                        <input 
                            type="text" 
                            className="input-field !pl-16 !rounded-2xl !py-4 !bg-surface" 
                            placeholder="Select Customer Unit..." 
                            value={customerSearch || (selectedShopId === 'WALKIN' ? 'Default Walking Customer' : customerInfo.name)}
                            onFocus={() => {
                                setShowCustomerDropdown(true);
                                setCustomerSearch('');
                            }}
                            onChange={e => {
                                setCustomerSearch(e.target.value);
                                setShowCustomerDropdown(true);
                            }}
                        />
                        
                        {showCustomerDropdown && (
                            <div className="absolute top-full left-0 right-0 bg-surface rounded-bento border border-black/5 shadow-2xl z-[100] mt-4 max-h-[300px] overflow-hidden flex flex-col animate-in fade-in slide-in-from-top-4 duration-500">
                                <div className="overflow-y-auto">
                                    <div 
                                        className={`p-6 cursor-pointer border-b border-black/5 font-black text-xs tracking-widest uppercase hover:bg-canvas transition-colors ${selectedShopId === 'WALKIN' ? 'bg-accent-signature/20 text-ink-primary' : 'text-ink-secondary'}`}
                                        onClick={() => {
                                            setSelectedShopId('WALKIN');
                                            setCustomerInfo({ name: 'Walk-in Customer', phone: '' });
                                            setCustomerSearch('');
                                            setShowCustomerDropdown(false);
                                        }}
                                    >
                                        DEFAULT UNIT (WALKING)
                                    </div>
                                    {filteredCustomers.map(s => (
                                        <div 
                                            key={s.id} 
                                            className={`p-6 cursor-pointer border-b border-black/5 hover:bg-canvas transition-colors ${selectedShopId === s.id ? 'bg-accent-signature/20' : ''}`}
                                            onClick={() => {
                                                setSelectedShopId(s.id);
                                                setCustomerInfo({ name: s.name, phone: s.phone || '' });
                                                setCustomerSearch('');
                                                setShowCustomerDropdown(false);
                                            }}
                                        >
                                            <div className="font-black text-ink-primary text-sm uppercase tracking-tight">{s.name}</div>
                                            <div className="text-xs font-black text-ink-secondary uppercase opacity-40 mt-1 tracking-widest">{s.phone}</div>
                                        </div>
                                    ))}
                                    {filteredCustomers.length === 0 && (
                                        <div className="p-10 text-center text-xs font-black uppercase tracking-widest text-ink-secondary opacity-30">No matches found</div>
                                    )}
                                </div>
                            </div>
                        )}
                        {showCustomerDropdown && (
                            <div className="fixed inset-0 z-[90]" onClick={() => setShowCustomerDropdown(false)} />
                        )}
                    </div>
                </div>
                
                {selectedShopId === 'WALKIN' && !showCustomerDropdown && (
                    <div className="flex gap-4">
                        <input type="text" className="input-field !rounded-2xl flex-1 text-xs !bg-surface" placeholder="NAME" value={customerInfo.name} onChange={e => setCustomerInfo({...customerInfo, name: e.target.value})} />
                        <input type="text" className="input-field !rounded-2xl flex-1 text-xs !bg-surface" placeholder="PHONE" value={customerInfo.phone} onChange={e => setCustomerInfo({...customerInfo, phone: e.target.value})} />
                    </div>
                )}
                
                {selectedShopId !== 'WALKIN' && !showCustomerDropdown && (
                    <div className="flex items-center gap-4 bg-ink-primary p-5 rounded-2xl shadow-xl">
                        <div className="w-12 h-12 rounded-pill bg-accent-signature flex items-center justify-center shrink-0">
                            <User size={20} className="text-ink-primary" />
                        </div>
                        <div className="min-w-0">
                            <div className="text-sm font-black text-surface uppercase truncate tracking-tight">{customerInfo.name}</div>
                            <div className="text-xs font-black text-surface/40 uppercase tracking-widest truncate">{customerInfo.phone}</div>
                        </div>
                    </div>
                )}
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto px-6 py-6 custom-scrollbar space-y-4">
                {cart.length === 0 ? (
                    <div className="text-center py-32 opacity-10">
                        <div className="flex justify-center mb-6">
                            <CartIcon size={80} strokeWidth={1} />
                        </div>
                        <p className="text-sm font-black uppercase tracking-[0.5em]">Inventory queue: Empty</p>
                    </div>
                ) : (
                    cartCalc.lines.map(item => (
                        <div key={item.productId} className="p-6 rounded-bento bg-surface border border-black/5 hover:shadow-premium transition-all group">
                            <div className="flex justify-between items-start mb-8">
                                <div className="min-w-0">
                                    <div className="text-base font-black text-ink-primary uppercase tracking-tight truncate leading-none mb-2">{item.name}</div>
                                    <div className="text-xs font-black text-ink-secondary uppercase tracking-[0.3em] opacity-40">{item.sku}</div>
                                </div>
                                <button 
                                    onClick={() => setCart(cart.filter(i => i.productId !== item.productId))} 
                                    className="w-10 h-10 rounded-pill bg-red-50 text-red-500 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500 hover:text-surface"
                                >
                                    <X size={16} />
                                </button>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-6">
                                <div>
                                    <div className="text-xs font-black uppercase tracking-[0.3em] text-ink-secondary mb-3 opacity-50 text-center">Volume</div>
                                    <div className="flex items-center bg-canvas rounded-pill overflow-hidden px-2 border border-black/5">
                                        <button onClick={() => removeFromCart(item.productId)} className="p-3 text-ink-primary hover:text-accent-signature transition-colors">
                                            <Minus size={14} />
                                        </button>
                                        <input 
                                            type="number" 
                                            value={item.quantity} 
                                            onChange={e => updateCartItem(item.productId, 'quantity', e.target.value)} 
                                            className="w-full text-center bg-transparent border-none text-sm font-black text-ink-primary outline-none"
                                        />
                                        <button onClick={() => addToCart(products.find(p => p.id === item.productId))} className="p-3 text-ink-primary hover:text-accent-signature transition-colors">
                                            <Plus size={14} />
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <div className="text-xs font-black uppercase tracking-[0.3em] text-ink-secondary mb-3 opacity-50 text-center">Unit Price</div>
                                    <div className="relative">
                                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs font-black text-ink-primary opacity-20">{businessProfile?.currencySymbol || '$'}</span>
                                        <input type="number" className="input-field !p-3 !pl-10 !rounded-pill !text-sm !font-black !bg-canvas border border-black/5" value={item.price} onChange={e => updateCartItem(item.productId, 'price', e.target.value)} />
                                    </div>
                                </div>
                                <div>
                                    <div className="text-xs font-black uppercase tracking-[0.3em] text-ink-secondary mb-3 opacity-50 text-center">Rebate %</div>
                                    <div className="relative">
                                        <Percent size={12} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-primary opacity-20" />
                                        <input type="number" className="input-field !p-3 !pr-10 !rounded-pill !text-sm !font-black !bg-canvas border border-black/5" value={item.discount} onChange={e => updateCartItem(item.productId, 'discount', e.target.value)} placeholder="0" />
                                    </div>
                                </div>
                            </div>
                            <div className="mt-8 pt-6 border-t border-dashed border-black/10 flex justify-between items-center text-sm">
                                <span className="font-black text-ink-secondary uppercase tracking-[0.2em] opacity-40">Line Aggregate</span>
                                <span className="font-black text-ink-primary tracking-tighter text-lg">
                                    {businessProfile?.currencySymbol || '$'}{item.lineTotal.toLocaleString()}
                                </span>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {/* Summary & Checkout Actions */}
            <div className="p-6 border-t border-black/5 bg-surface/50 backdrop-blur-3xl shadow-2xl">
                <div className="space-y-4 mb-10">
                    <div className="flex justify-between text-sm font-black uppercase tracking-[0.3em] text-ink-secondary opacity-50">
                        <span>Gross Aggregate ({cartCalc.totalItems} units)</span>
                        <span>{businessProfile?.currencySymbol || '$'}{cartCalc.subtotal.toLocaleString()}</span>
                    </div>
                    {cartCalc.totalDiscount > 0 && (
                        <div className="flex justify-between text-sm font-black uppercase tracking-[0.3em] text-red-500">
                            <span>Transactional Rebate</span>
                            <span>-{businessProfile?.currencySymbol || '$'}{cartCalc.totalDiscount.toLocaleString()}</span>
                        </div>
                    )}
                    <div className="flex justify-between items-end pt-6 border-t border-black/5">
                        <span className="text-sm font-black uppercase tracking-[0.4em] text-ink-primary">Net Capital</span>
                        <span className="text-5xl font-black text-ink-primary tracking-tighter">
                            {businessProfile?.currencySymbol || '$'}{cartCalc.finalTotal.toLocaleString()}
                        </span>
                    </div>
                </div>

                <div className="flex gap-6">
                    <button 
                        className="flex-1 py-7 rounded-pill border border-black/10 font-black text-ink-primary hover:bg-black/5 transition-all text-xs tracking-widest uppercase disabled:opacity-30 disabled:cursor-not-allowed" 
                        disabled={cart.length === 0 || isViewOnly()} 
                        onClick={() => setShowBookingDateModal(true)}
                    >
                        PRE-BOOK
                    </button>
                    <button 
                        className="btn-signature flex-[1.5] py-7 text-base rounded-pill !h-24" 
                        disabled={cart.length === 0 || isViewOnly()} 
                        onClick={() => setShowPaymentModal(true)}
                    >
                        CHECKOUT
                        <div className="icon-nest ml-6">
                            <Check size={28} />
                        </div>
                    </button>
                </div>
            </div>
        </div>
    );

    return (
        <div className="animate-fade-in flex flex-col lg:flex-row gap-8 lg:h-[calc(100vh-140px)]">
            <div className="flex-1 flex flex-col gap-8 min-h-0">
                {/* Header Section */}
                <div className="flex justify-between items-end pb-8 border-b border-black/5">
                    <div>
                        <h1 className="text-7xl font-black tracking-tighter text-ink-primary uppercase leading-none mb-4">Store.</h1>
                        <p className="text-sm font-medium text-ink-secondary tracking-tight uppercase opacity-50">Central Transaction Terminal</p>
                    </div>
                    {!isMobile && (
                        <div className="text-right">
                            <div className="text-5xl font-black text-ink-primary tracking-tighter leading-none mb-2">{filteredProducts.length}</div>
                            <div className="text-sm font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40">Active SKU Assets</div>
                        </div>
                    )}
                </div>

                {/* Controls Section */}
                <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex-1 relative group">
                        <Search size={24} className="absolute left-8 top-1/2 -translate-y-1/2 text-ink-primary opacity-20 group-focus-within:opacity-100 transition-opacity" />
                        <input 
                            type="text" 
                            className="input-field !pl-20 !py-8 !rounded-pill bg-surface border-black/5 shadow-premium !text-lg font-black" 
                            placeholder="Identify inventory asset..." 
                            value={searchTerm} 
                            onChange={e => setSearchTerm(e.target.value)} 
                        />
                    </div>
                    {activeRoutes.length > 0 && (
                        <div className="relative group min-w-[300px]">
                            <Truck size={22} className="absolute left-8 top-1/2 -translate-y-1/2 text-ink-primary opacity-20" />
                            <select 
                                className="input-field !pl-20 !py-8 !rounded-pill bg-surface border-black/5 shadow-premium appearance-none font-black text-[11px] tracking-[0.3em] uppercase cursor-pointer" 
                                value={selectedRoute} 
                                onChange={e => setSelectedRoute(e.target.value)}
                            >
                                <option value="">MAIN INFRASTRUCTURE</option>
                                {activeRoutes.map(r => <option key={r.id} value={r.id}>LOGISTICS UNIT: {r.driverId}</option>)}
                            </select>
                        </div>
                    )}
                </div>

                {/* Category Filtering */}
                {categories.length > 1 && (
                    <div className="flex gap-3 overflow-x-auto pb-4 custom-scrollbar">
                        {categories.map(cat => (
                            <button
                                key={cat}
                                onClick={() => setSelectedCategory(cat)}
                                className={`px-10 py-5 rounded-pill text-[10px] font-black uppercase tracking-[0.3em] transition-all whitespace-nowrap border ${
                                    selectedCategory === cat 
                                    ? 'bg-ink-primary text-surface border-transparent shadow-2xl scale-105' 
                                    : 'bg-surface text-ink-secondary border-black/5 hover:border-black/20'
                                }`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                )}

                {/* Product Catalog Grid */}
                <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
                        {filteredProducts.map(product => {
                            const inCart = cart.find(i => i.productId === product.id);
                            
                            return (
                                <div 
                                    key={product.id} 
                                    onClick={() => addToCart(product)}
                                    className={`glass-panel !p-0 !rounded-bento relative overflow-hidden group cursor-pointer transition-all border border-black/5 bg-surface ${
                                        inCart ? 'ring-8 ring-accent-signature/20 ring-offset-4 ring-offset-canvas shadow-2xl scale-[1.02]' : 'hover:-translate-y-4 hover:shadow-premium'
                                    }`}
                                >
                                    {inCart && (
                                        <div className="absolute top-8 right-8 w-12 h-12 rounded-pill bg-accent-signature text-ink-primary flex items-center justify-center font-black text-sm z-10 shadow-2xl animate-scale-up">
                                            {inCart.quantity}
                                        </div>
                                    )}
                                    
                                    <div className="aspect-square bg-canvas flex items-center justify-center p-12 transition-transform group-hover:scale-110 duration-700">
                                        {product.image ? (
                                            <img src={product.image} alt={product.name} className="w-full h-full object-contain" />
                                        ) : (
                                            <Package size={80} className="text-ink-primary opacity-5 stroke-[1]" />
                                        )}
                                    </div>

                                    <div className="p-6 bg-surface border-t border-black/5">
                                        <div className="text-sm font-black text-ink-secondary uppercase tracking-[0.4em] mb-3 opacity-40">{product.sku}</div>
                                        <h3 className="text-base font-black text-ink-primary uppercase tracking-tight mb-8 line-clamp-1 leading-none">{product.name}</h3>
                                        
                                        <div className="flex justify-between items-end">
                                            <div>
                                                <div className="text-xs font-black text-ink-secondary uppercase tracking-[0.3em] mb-2 opacity-50">Market Price</div>
                                                <div className="text-3xl font-black text-ink-primary tracking-tighter">
                                                    {businessProfile?.currencySymbol || '$'}{product.sellingPrice.toLocaleString()}
                                                </div>
                                            </div>
                                            <div className={`px-4 py-2 rounded-pill text-xs font-black uppercase tracking-[0.2em] shadow-sm ${
                                                product.stock <= 10 ? 'bg-red-50 text-red-500 border border-red-100' : 'bg-canvas text-ink-primary border border-black/5'
                                            }`}>
                                                {product.stock} {product.unit || 'Units'}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    {filteredProducts.length === 0 && (
                        <div className="flex flex-col items-center justify-center py-32 opacity-10">
                            <Grid3X3 size={80} strokeWidth={1} />
                            <p className="text-xs font-black uppercase tracking-[0.4em] mt-8">Empty Sector Search</p>
                        </div>
                    )}
                </div>
            </div>

            {/* Desktop Cart Sidebar */}
            {!isMobile && (
                <div className="w-[500px] shrink-0 sticky top-0 group">
                    <div className="glass-panel !p-0 !rounded-bento h-full overflow-hidden flex flex-col border border-black/5 shadow-2xl group-hover:shadow-premium transition-all bg-surface">
                        {renderCartPanel()}
                    </div>
                </div>
            )}

            {/* Mobile Bottom Bar for Cart */}
            {isMobile && !mobileCartOpen && cart.length > 0 && (
                <div onClick={() => setMobileCartOpen(true)} className="fixed bottom-6 left-6 right-6 bg-[#111] text-white p-6 rounded-[2.5rem] flex justify-between items-center z-[100] shadow-2xl active:scale-95 transition-transform">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-[#C8F135] flex items-center justify-center text-black">
                            <CartIcon size={20} />
                        </div>
                        <div>
                            <div className="text-xs font-black uppercase tracking-[0.2em] opacity-40">Queue Units</div>
                            <div className="text-lg font-black tracking-tighter">{cartCalc.totalItems} Items</div>
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="text-xs font-black uppercase tracking-[0.2em] text-[#C8F135]">Aggregate</div>
                        <div className="text-2xl font-black tracking-tighter">{businessProfile?.currencySymbol || '$'}{cartCalc.finalTotal.toLocaleString()}</div>
                    </div>
                </div>
            )}

            {/* Mobile Cart Overlay */}
            {isMobile && mobileCartOpen && (
                <div className="fixed inset-0 bg-canvas/80 backdrop-blur-3xl z-[1000] animate-in fade-in transition-all overflow-hidden flex flex-col">
                    <div className="flex-1 overflow-hidden">
                        {renderCartPanel()}
                    </div>
                </div>
            )}

            {/* Payment Modal */}
            {showPaymentModal && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[500px]">
                        <button 
                            onClick={() => setShowPaymentModal(false)}
                            className="absolute top-10 right-10 w-16 h-16 rounded-pill bg-canvas flex items-center justify-center text-ink-primary hover:scale-110 transition-transform shadow-premium"
                        >
                            <X size={28} />
                        </button>

                        <div className="text-center mb-16">
                            <h3 className="text-5xl font-black tracking-tighter text-ink-primary uppercase mb-4">Final Settlement.</h3>
                            <p className="text-xs font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40">Identify Payment Vector</p>
                        </div>
                        
                        <div className="p-12 bg-canvas rounded-bento border border-black/5 mb-16 text-center">
                            <div className="text-sm font-black uppercase tracking-[0.4em] text-ink-secondary mb-4 opacity-40">Capital Payable</div>
                            <div className="text-6xl font-black text-ink-primary tracking-tighter">{businessProfile?.currencySymbol || '$'}{cartCalc.finalTotal.toLocaleString()}</div>
                        </div>

                        <div className="grid grid-cols-2 gap-8 mb-16">
                            {[
                                { id: 'CASH', label: 'Liquid Cash', icon: Banknote },
                                { id: 'CREDIT', label: 'Credit Card', icon: CreditCard }
                            ].map(method => (
                                <button
                                    key={method.id}
                                    onClick={() => setPendingPaymentMethod(method.id)}
                                    className={`p-8 rounded-bento border-4 transition-all flex flex-col items-center gap-6 group ${
                                        pendingPaymentMethod === method.id 
                                        ? 'border-ink-primary bg-ink-primary text-surface shadow-2xl scale-105' 
                                        : 'border-black/5 bg-surface text-ink-primary hover:border-black/20 hover:scale-[1.02]'
                                    }`}
                                >
                                    <method.icon size={48} className={pendingPaymentMethod === method.id ? 'text-accent-signature' : 'group-hover:scale-110 transition-transform opacity-30'} />
                                    <span className="text-sm font-black uppercase tracking-[0.3em] leading-none">{method.label}</span>
                                </button>
                            ))}
                        </div>

                        <div className="flex gap-6">
                            <button className="flex-1 py-7 rounded-pill border border-black/10 font-black text-ink-primary hover:bg-black/5 transition-all uppercase text-[10px] tracking-widest" onClick={() => setShowPaymentModal(false)}>Cancel</button>
                            <button className="btn-signature flex-[2] !h-[84px] !text-base" onClick={() => handleConfirmTransaction('COMPLETED')}>
                                SETTLE ACCOUNT
                                <div className="icon-nest ml-6">
                                    <Check size={28} />
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Booking Date Modal */}
            {showBookingDateModal && (
                <div className="modal-overlay">
                    <div className="glass-modal !max-w-[450px]">
                        <button 
                            onClick={() => setShowBookingDateModal(false)}
                            className="absolute top-10 right-10 w-16 h-16 rounded-pill bg-canvas flex items-center justify-center text-ink-primary hover:scale-110 transition-transform shadow-premium"
                        >
                            <X size={24} />
                        </button>

                        <div className="text-center mb-16">
                            <h3 className="text-4xl font-black tracking-tighter text-ink-primary uppercase mb-4">Pre-Book Unit.</h3>
                            <p className="text-xs font-black text-ink-secondary uppercase tracking-[0.4em] opacity-40">Set Fulfillment Chronology</p>
                        </div>
                        
                        <div className="mb-16">
                            <label className="block text-sm font-black uppercase tracking-[0.3em] text-ink-secondary mb-6 text-center opacity-60">Logistics Target Date</label>
                            <input 
                                type="date" 
                                className="w-full bg-canvas border border-black/5 rounded-bento p-10 font-black text-4xl text-center text-ink-primary outline-none focus:ring-8 focus:ring-accent-signature/20 transition-all" 
                                value={scheduledDate} 
                                onChange={e => setScheduledDate(e.target.value)}
                                min={new Date().toISOString().split('T')[0]}
                            />
                        </div>

                        <div className="flex gap-6">
                            <button className="flex-1 py-7 rounded-pill border border-black/10 font-black text-ink-primary hover:bg-black/5 transition-all text-[10px] tracking-[0.2em] uppercase" onClick={() => setShowBookingDateModal(false)}>CANCEL</button>
                            <button className="btn-signature flex-[2] !h-[84px] !text-base" onClick={() => handleConfirmTransaction('PENDING')}>
                                AUTHORIZE PRE-BOOK
                                <div className="icon-nest ml-6">
                                    <Clock size={28} />
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Sales;
